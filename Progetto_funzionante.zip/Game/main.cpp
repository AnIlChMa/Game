#include <iostream>
#include <cstdlib>
#include "mappa.hpp"
#include "stanza.hpp"
#include <ctime>
#include <curses.h>
#include <ncurses.h>
#include "screen.hpp"
#include "Position.hpp"
#include <vector>
#include "character.hpp"
#include "mostro.hpp"
#include "oggetto.hpp"
using namespace std;



int main()
{
    
     initscr();
    noecho();
    mvwprintw(stdscr, 2, 2, "%s","è la notte del 31 ottobre, il cielo si è fatto grigio cupo e la città silenziosa; tutti si stanno preparando alla notte più spaventosa di tutto l anno. C è chi per troppa paura si chiude in casa, e chi come te, coraggioso e un po spavaldo decide di uscire per le strade della città. E se l antica leggenda diventasse realtà?! Stai attento ragazzo/a non sai cosa ti aspetta là fuori, mostri(M) di ogni tipo sono pronti ad attaccarti, guardati sempre alle spalle, non ti fidare di nessuno e cerca di tornare a casa vivo stanotte.Cè   solo un modo per sopravvivere e mille per morire, nessuno ti aiuterà pensa a raccogliere più dolcetti che puoi, impara scherzi sempre più spaventosi per riuscire  a combattere i mostri, e mi raccomando se dovessi trovare una lanterna prendila, ma usala solo quando sarà davvero necessario, perché potrebbe essere l unica che troverai sul tuo cammino. I dolcetti (o) saranno le tue energie, ciò che ti manterrà in vita. Gli scherzi(a) saranno per  te armi per combattere i mostri che cercheranno di ucciderti. Con la lanterna(v) che ti illumina la strada, avrai meno paura dei mostri.Per usare gli oggetti che hai raccolto basta che digiti il simbolo corrispondente.Vuoi sopravvivere?! Raggiungi casa (c) tua, sempre  se riuscirai a ricordarti la strada. Per iniziare il gioco premi un tasto");
    
    wrefresh(stdscr);
    stanza bla;
    screen finestra;
    position posit;
    finestra.inizializzafinestra();
    mappa pippo;
    character chr;
    character * chari= new character;
    mostro mst;
    mostro *most= new mostro;
    oggetto dolcetti('o',"dolcetti");
    
    oggetto scherzi ('a',"scherzi"); //l'arma se usata aumenta la potenza d'attacco del personaggio
    
    oggetto chiave('j',"chiave");
    
    oggetto lanterna('v',"lanterna");//l'oggetto vita se usata aumenta la difesa del personaggio
    
    oggetto casa('c',"casa"); //destinazione per vincere
    pippo.creamappa();
    
    finestra.statusmonete(finestra.win2, chr.monete);
    finestra.statuspersonaggio(finestra.win2, chari->vita, chari->attacco, chari->difesa);
    posit.crealivello(finestra.win1,finestra.win2, pippo, finestra,chari,most,posit); //crea la prima stanza
    
    posit.generaoggetti(finestra.win1, pippo,dolcetti, posit,chr);
    posit.generaoggetti(finestra.win1, pippo, scherzi, posit,chr);
    posit.generaoggetti(finestra.win1, pippo, lanterna, posit,chr);
    
    
    if(chr.vivo(finestra.win2, finestra)==FALSE){
        wprintw(finestra.win1, "%s", "GAME OVER");
    }
    else{
    keypad(stdscr, TRUE);
    
   

    while(chr.vivo(finestra.win2, finestra)==TRUE){
        if(posit.level<=1){
            posit.posmove(finestra.win1,finestra.win2,finestra.win3, pippo, finestra,most, chari,posit);
            }
        if(posit.level>1){
           
            posit.generaoggetti(finestra.win1, pippo,dolcetti, posit,chr);
            posit.generaoggetti(finestra.win1, pippo, scherzi, posit,chr);
            posit.generaoggetti(finestra.win1, pippo, lanterna, posit,chr);
            posit.generaoggetti(finestra.win1, pippo, casa, posit,chr);
            posit.generamostri(finestra.win1, finestra.win2, pippo, most, posit, finestra, chr);
            while(chr.vivo(finestra.win2, finestra)==TRUE){
                
                posit.posmove(finestra.win1,finestra.win2,finestra.win3, pippo, finestra,most, chari,posit);
                 
                most->movimento(finestra.win1,finestra.win2, pippo, posit,finestra,chari);
            }
        }
        chr.usaoggetti(finestra.win1,finestra.win3, pippo, posit,finestra );
    }
        
        
  
    
    
    }
    
    getch();
    endwin();
    return 0;
}
