//
//  mostro.hpp
//  Game
//
//  Created by chiara mengoli on 25/10/17.
//  Copyright © 2017 chiara mengoli. All rights reserved.
//

#ifndef mostro_hpp
#define mostro_hpp

#include <stdio.h>
#include "mappa.hpp"
#include "screen.hpp"
#include "character.hpp"
#include "Position.hpp"


class mostro: public character{
    public:
    mostro();
    void charactervsmostro(WINDOW *win1,WINDOW *win2, screen scr,character *chr);
    void movimento(WINDOW *win1,WINDOW *win2, mappa mapp, position pos, screen scr,character *chr);
    void mostrovscharacter(WINDOW *win1,WINDOW *win2, screen scr,character *chr);
    int mostrox;
    int mostroy;
    int mostroi;
    int mostroj;
   
};



#endif /* mostro_hpp */
