//
//  oggetto.cpp
//  Game
//
//  Created by chiara mengoli on 31/10/17.
//  Copyright © 2017 chiara mengoli. All rights reserved.
//

#include "oggetto.hpp"

oggetto::oggetto(char s, char d[15]){
    symbol=s;
    for(int i=0;i<15;i++){
    descr[i]=d[i];
    }
}
