
//
//  character.cpp
//  Game
//
//  Created by chiara mengoli on 25/10/17.
//  Copyright © 2017 chiara mengoli. All rights reserved.
//

#include "character.hpp"
#include "Position.hpp"
#include <ncurses.h>
#include <curses.h>
#include <iostream>
#include <string.h>
character::character()
{
    attacco=1000;
    difesa=600;
    nome='$';
    vita=1000;
    for(int i = 0;i<10;i++){
    loggetti[i]=' ';
    }
    loggetti[10]='\0';
    monete=0;
    r=0;
   
}


bool character::vivo(WINDOW *win2, screen scr){
   // scr.statuspersonaggio(win2, vita,attacco,difesa);
    if(vita<=0)
        return false;
    else
        return true;
}

void character::raccoglioggetti(WINDOW *win1,WINDOW *win2,WINDOW *win3,position pos,mappa map,screen scr,int p,character *chr){
    
    switch(p){
        case 1:
        {
            if(map.strutturamappa[pos.posi][pos.posj]->room[pos.posx-1][pos.posy]=='a'){
               chr->r++;
                chr->loggetti[r]='a';
               
                scr.stampaoggetti(win3,loggetti);
                wrefresh(win3);
            }
            else if (map.strutturamappa[pos.posi][pos.posj]->room[pos.posx-1][pos.posy]=='o'){
                chr->monete+=20 ;
                
                scr.statusmonete(win2,chr->monete);
               
                wrefresh(win2);
                if(chr->monete>=pos.h)
                    pos.generachiave(win1, map, chr);
            }
            else if (map.strutturamappa[pos.posi][pos.posj]->room[pos.posx-1][pos.posy]=='j'){
                chr->r++;
                chr->loggetti[r]='j';
                
                scr.stampaoggetti(win3,chr->loggetti);
                wrefresh(win3);
            }
            else if (map.strutturamappa[pos.posi][pos.posj]->room[pos.posx-1][pos.posy]=='v'){
                chr->r++;
                chr->loggetti[r]='v';
                
                scr.stampaoggetti(win3,chr->loggetti);
                wrefresh(win3);
            }
        }
            break;
        case 2:
        {
            if(map.strutturamappa[pos.posi][pos.posj]->room[pos.posx][pos.posy+1]=='a'){
                chr->r++;
                chr->loggetti[r]='a';
                
                scr.stampaoggetti(win3,chr->loggetti);
                wrefresh(win3);
            }
            else if (map.strutturamappa[pos.posi][pos.posj]->room[pos.posx][pos.posy+1]=='o'){
                chr->monete+=20;
                
                scr.statusmonete(win2,chr->monete);
                wrefresh(win2);
                if(chr->monete>=pos.h)
                    pos.generachiave(win1, map, chr);
            }
            else if (map.strutturamappa[pos.posi][pos.posj]->room[pos.posx][pos.posy+1]=='j'){
                chr->r++;
                chr->loggetti[r]='j';
                
               scr.stampaoggetti(win3,chr->loggetti);
                wrefresh(win3);
            }
            else if (map.strutturamappa[pos.posi][pos.posj]->room[pos.posx][pos.posy+1]=='v'){
                chr->r++;
                chr->loggetti[r]='v';
                scr.stampaoggetti(win3,chr->loggetti);
                wrefresh(win3);
            }
        }
            break;
        case 3:
        {
            if(map.strutturamappa[pos.posi][pos.posj]->room[pos.posx+1][pos.posy]=='a'){
                chr->r++;
                chr->loggetti[r]='a';
                scr.stampaoggetti(win3,chr->loggetti);
                wrefresh(win3);
            }
            else if (map.strutturamappa[pos.posi][pos.posj]->room[pos.posx+1][pos.posy]=='o'){
                chr->monete+=20;
                

                scr.statusmonete(win2,chr->monete);
                wrefresh(win2);
                if(chr->monete>=pos.h)
                    pos.generachiave(win1, map, chr);

            }
            else if (map.strutturamappa[pos.posi][pos.posj]->room[pos.posx+1][pos.posy]=='j'){
                chr->r++;
                chr->loggetti[r]='j';
                
               scr.stampaoggetti(win3,chr->loggetti);
                wrefresh(win3);
            }
            else if (map.strutturamappa[pos.posi][pos.posj]->room[pos.posx+1][pos.posy]=='v'){
                chr->r++;
                chr->loggetti[r]='v';
                
                scr.stampaoggetti(win3,chr->loggetti);
                wrefresh(win3);
            }
        }
            break;
        case 4:
        {
            if(map.strutturamappa[pos.posi][pos.posj]->room[pos.posx][pos.posy-1]=='a'){
                chr->r++;
                chr->loggetti[r]='a';
                
                scr.stampaoggetti(win3,chr->loggetti);
                wrefresh(win3);
            }
            else if (map.strutturamappa[pos.posi][pos.posj]->room[pos.posx][pos.posy-1]=='o'){
                chr->monete+=20;
                
                scr.statusmonete(win2,chr->monete);
                wrefresh(win2);
                if(chr->monete>=pos.h)
                    pos.generachiave(win1, map, chr);

            }
            else if (map.strutturamappa[pos.posi][pos.posj]->room[pos.posx][pos.posy-1]=='j'){
                chr->r++;
                chr->loggetti[r]='j';
                
               scr.stampaoggetti(win3,chr->loggetti);
                wrefresh(win3);
            }
            else if (map.strutturamappa[pos.posi][pos.posj]->room[pos.posx][pos.posy-1]=='v'){
                chr->r++;
                chr->loggetti[r]='v';
                
                scr.stampaoggetti(win3,chr->loggetti);
                wrefresh(win3);
            }
        }
            break;

    }
   
}
    




//questa funzione dovrebbe permettere di usare gli oggeti ->svuotare la lista degli oggetti
//adesso sta generando la chiave, dovrebbe essere integrata alla funzione generahiave
void character::usaoggetti(WINDOW *win1,WINDOW *win3,mappa map, position pos ,screen scr){
    int ch=0;
    if((ch=getch())!='q'){
        switch(ch){
                case 'a':
                    {
                        
                    attacco=attacco+200;
                        for(r=0;r<10;r++){
                            if(loggetti[r]=='a')
                                loggetti[r]=' ';
                        }
                       scr.stampaoggetti(win3,loggetti);
                    }
                    break;
                case 'v':
                {
                    difesa=difesa+200;
                    for(r=0;r<10;r++){
                        if(loggetti[r]=='v')
                            loggetti[r]=' ';
                    }
                    scr.stampaoggetti(win3,loggetti);

                }
                    break;
                default:
                break;
        }
    }
}
    
    
    
    
        
  
    
    
    
