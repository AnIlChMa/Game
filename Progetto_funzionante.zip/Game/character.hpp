//
//  character.hpp
//  Game
//
//  Created by chiara mengoli on 25/10/17.
//  Copyright © 2017 chiara mengoli. All rights reserved.
//

#ifndef character_hpp
#define character_hpp

#include <stdio.h>

#include "mappa.hpp"
#include "screen.hpp"
#include "oggetto.hpp"



class position;
class character {
public:
    character();
    
    bool vivo(WINDOW *win2, screen scr);
   void raccoglioggetti(WINDOW *win1,WINDOW *win2,WINDOW *win3,position pos,mappa map,screen scr,int p,character *chr);
   void usaoggetti(WINDOW *win1,WINDOW *win3, mappa map,position pos,screen scr);
    void stampaoggetti(WINDOW *win3);
    int monete;
     char nome;
    char descr;
    int vita;
    int difesa;
    int attacco;
    char loggetti[11];
    int r;
    
    
private:

};



#endif /* character_hpp */
