//
//  oggetto.hpp
//  Game
//
//  Created by chiara mengoli on 31/10/17.
//  Copyright © 2017 chiara mengoli. All rights reserved.
//

#ifndef oggetto_hpp
#define oggetto_hpp

#include <stdio.h>

class oggetto{
public:
    oggetto(char s, char d[15]);
    char symbol;
    char descr[15];
    int oggx;
    int oggy;

};



#endif /* oggetto_hpp */
