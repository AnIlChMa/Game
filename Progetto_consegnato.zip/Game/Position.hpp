//
//  Position.hpp
//  Game
//
//  Created by chiara mengoli on 19/10/17.
//  Copyright © 2017 chiara mengoli. All rights reserved.
//

#ifndef Position_hpp
#define Position_hpp

#include <stdio.h>
#include <curses.h>
#include <ncurses.h>
#include "mappa.hpp"
#include "character.hpp"
#include "oggetto.hpp"
class mostro;
class position {
    
    
public:
    position();
    
    void posmove(WINDOW *win1,WINDOW *win2,WINDOW *win3,mappa map, screen scr, mostro mst,character chr, position pos);
    void passaporta(WINDOW *win1,WINDOW *win2,WINDOW *win3, mappa map, screen scr,mostro mst, character chr, position pos);
     void crealivello(WINDOW *win1,WINDOW *win2,mappa map, screen scr, character chr, mostro mst, position pos);
    void generachiave(WINDOW *win1,mappa map,character chr);
    void generamostri(WINDOW *win1,WINDOW *win2,mappa map, mostro mst,position pos,screen scr,character chr);
    void generaoggetti(WINDOW *win1,mappa map,oggetto ogg,position pos,character chr);
    int posx;
    int posy;
    int posi;
    int posj;
    int level;
   
   
    int h;//valore di monete che permette la comparsa della chiave in una stanza per accedere al livello successivo
protected:
    int numstanza;
    
};
#endif /* Position_hpp */
