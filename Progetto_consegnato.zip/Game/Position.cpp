//
//  Position.cpp
//  Game
//
//  Created by chiara mengoli on 19/10/17.
//  Copyright © 2017 chiara mengoli. All rights reserved.
//

#include "Position.hpp"
#include <curses.h>
#include <ncurses.h>
#include "character.hpp"
#include "mostro.hpp"


position::position(){
  
    posy=1;
    posx=1;
    posi=2;
    posj=8;
    level=0;
    
    numstanza=0;
    h=50;
    }

//aggiungere un parametro per indicare chi si deve spostare (personaggio/mostro)
void position::posmove(WINDOW *win1,WINDOW *win2,WINDOW *win3, mappa map, screen scr,mostro mst,character chr, position pos){
    
    map.strutturamappa[posi][posj]->room[posx][posy]=chr.nome;
   map.esistestanza(win1);

    int ch=0;
    if((ch=getch())!= 'q')
    {
       
        switch(ch)
        {
            case KEY_UP:{
               
                if(map.strutturamappa[posi][posj]->room[posx-1][posy] !='-'){
                    if(map.strutturamappa[posi][posj]->room[posx-1][posy] =='M'){
                        mst.charactervsmostro(win1, win2, scr,chr);
                        map.strutturamappa[posi][posj]->room[ posx][ posy]=chr.nome;
                    }
                    if(map.strutturamappa[posi][posj]->room[posx-1][posy] =='c'){
                        mvwprintw(win1,2,2 ,"%s","HAI VINTO");
                        wrefresh(win1);
                    }
                    if( map.strutturamappa[posi][posj]->room[posx-1][posy] =='j' || map.strutturamappa[posi][posj]->room[posx-1][posy] =='o' || map.strutturamappa[posi][posj]->room[posx-1][posy] =='a'|| map.strutturamappa[posi][posj]->room[posx-1][posy] =='v'){
                        
                        if(map.strutturamappa[posi][posj]->room[posx-1][posy] =='j'){
                            crealivello(win1,win2, map,scr,chr,mst,pos);
                            chr.raccoglioggetti(win1,win2,win3,pos,map,scr,3,chr);
                        }
                        
                        chr.raccoglioggetti(win1,win2,win3,pos,map,scr,3,chr);
                        map.strutturamappa[posi][posj]->room[posx][posy]=' ';
                        posx--;
                        map.strutturamappa[posi][posj]->room[ posx][ posy]=chr.nome;
                    }
                    else if(map.strutturamappa[posi][posj]->room[posx-1][posy] ==' '){
                        map.strutturamappa[posi][posj]->room[posx][posy]=' ';
                        posx--;
                        map.strutturamappa[posi][posj]->room[ posx][ posy]=chr.nome;
                        map.esistestanza(win1);
                }
                    if(map.strutturamappa[posi][posj]->room[posx-1][posy] =='/' ){
                        passaporta(win1,win2,win3, map ,scr,mst,chr,pos);
                        
                    }
                    

                }
                else
                   
                    map.strutturamappa[posi][posj]->room[posx][posy]=chr.nome;
                break;
                            }
                
            case KEY_DOWN:{
                
                if(map.strutturamappa[posi][posj]->room[posx+1][posy] !='-' ){
                    if(map.strutturamappa[posi][posj]->room[posx+1][posy] =='M'){
                        mst.charactervsmostro(win1, win2, scr,chr);
                        
                        map.strutturamappa[posi][posj]->room[ posx][ posy]=chr.nome;
                    }
                    if(map.strutturamappa[posi][posj]->room[posx+1][posy] =='c'){
                        mvwprintw(win1,2,2 ,"%s","HAI VINTO");
                        wrefresh(win1);
                    }
                    if( map.strutturamappa[posi][posj]->room[posx+1][posy] =='j' || map.strutturamappa[posi][posj]->room[posx+1][posy] =='o' || map.strutturamappa[posi][posj]->room[posx+1][posy] =='a'|| map.strutturamappa[posi][posj]->room[posx+1][posy] =='v'){
                       
                        if(map.strutturamappa[posi][posj]->room[posx+1][posy] =='j'){
                            crealivello(win1,win2, map,scr,chr,mst,pos);
                            chr.raccoglioggetti(win1,win2,win3,pos,map,scr,3,chr);
                        }

                        chr.raccoglioggetti(win1,win2,win3,pos,map,scr,3,chr);
                        map.strutturamappa[posi][posj]->room[posx][posy]=' ';
                        posx++;
                        map.strutturamappa[posi][posj]->room[ posx][ posy]=chr.nome;
                    }
                    else if(map.strutturamappa[posi][posj]->room[posx+1][posy] ==' '){
                        map.strutturamappa[posi][posj]->room[ posx][ posy]=' ';
                        posx++;
                
                        map.strutturamappa[posi][posj]->room[ posx][ posy]=chr.nome;
                        map.esistestanza(win1);
                        }
                    if(map.strutturamappa[posi][posj]->room[posx+1][posy] =='/' ){
                        passaporta(win1,win2,win3, map ,scr,mst, chr,pos);
                        
                        
                    }
                }
                else
                    map.strutturamappa[posi][posj]->room[posx][posy]=chr.nome;
                break;
                
            }
                
            case KEY_RIGHT:{
                
                        if (map.strutturamappa[posi][posj]->room[posx][posy+1]!='|'){
                            if(map.strutturamappa[posi][posj]->room[posx][posy+1] =='M'){
                                mst.charactervsmostro(win1, win2, scr,chr);
                               
                                map.strutturamappa[posi][posj]->room[ posx][ posy]=chr.nome;
                            }
                            if(map.strutturamappa[posi][posj]->room[posx][posy+1] =='c'){
                                mvwprintw(win1,2,2, "%s","HAI VINTO");
                                wrefresh(win1);
                            }
                            if( map.strutturamappa[posi][posj]->room[posx][posy+1] =='j' || map.strutturamappa[posi][posj]->room[posx][posy+1] =='o' || map.strutturamappa[posi][posj]->room[posx][posy+1] =='a'|| map.strutturamappa[posi][posj]->room[posx][posy+1] =='v'){
                                if(map.strutturamappa[posi][posj]->room[posx][posy+1] =='j'){
                                    crealivello(win1,win2, map,scr,chr,mst,pos);
                                    chr.raccoglioggetti(win1,win2,win3,pos,map,scr,2,chr);
                                }
                               chr.raccoglioggetti(win1,win2,win3,pos,map,scr,2,chr);
                                map.strutturamappa[posi][posj]->room[posx][posy]=' ';
                                posy++;
                                map.strutturamappa[posi][posj]->room[ posx][ posy]=chr.nome;
                            }
                    
                    else if(map.strutturamappa[posi][posj]->room[posx][posy+1] ==' '){
                        map.strutturamappa[posi][posj]->room[ posx][ posy]=' ';
                        posy++;
                
                        map.strutturamappa[posi][posj]->room[ posx][ posy]=chr.nome;
                        map.esistestanza(win1);
                    }
                            if(map.strutturamappa[posi][posj]->room[posx][posy+1] =='/' ){
                                passaporta(win1,win2,win3, map ,scr,mst,chr,pos);
                            }
                }
                else
                    map.strutturamappa[posi][posj]->room[posx][posy]=chr.nome;
                break;
                
            }
                
            case KEY_LEFT:{
              

                if(map.strutturamappa[posi][posj]->room[posx][posy-1]!='|'){
                    if(map.strutturamappa[posi][posj]->room[posx][posy-1] =='M'){
                        mst.charactervsmostro(win1, win2, scr,chr);
                        
                        map.strutturamappa[posi][posj]->room[ posx][ posy]=chr.nome;
                    }
                    if(map.strutturamappa[posi][posj]->room[posx][posy-1] =='c'){
                        mvwprintw(win1,2,2 ,"%s","HAI VINTO");
                        wrefresh(win1);
                    }

                    if( map.strutturamappa[posi][posj]->room[posx][posy-1] =='j' || map.strutturamappa[posi][posj]->room[posx][posy-1] =='o' || map.strutturamappa[posi][posj]->room[posx][posy-1] =='a'|| map.strutturamappa[posi][posj]->room[posx][posy-1] =='v'){
                        if(map.strutturamappa[posi][posj]->room[posx][posy-1] =='j'){
                            crealivello(win1,win2, map,scr,chr,mst,pos);
                            chr.raccoglioggetti(win1,win2,win3,pos,map,scr,4,chr);
                        }
                      chr.raccoglioggetti(win1,win2,win3,pos,map,scr,4,chr);
                        
                        map.strutturamappa[posi][posj]->room[posx][posy]=' ';
                        posy--;
                        map.strutturamappa[posi][posj]->room[ posx][ posy]=chr.nome;
                    }
                    
                    else if(map.strutturamappa[posi][posj]->room[posx][posy-1] ==' '){
                        map.strutturamappa[posi][posj]->room[ posx][ posy]=' ';
                        posy--;
                
                        map.strutturamappa[posi][posj]->room[ posx][ posy]=chr.nome;
                        map.esistestanza(win1);
                    }
                    if(map.strutturamappa[posi][posj]->room[posx][posy-1] =='/' ){
                        passaporta(win1,win2,win3, map ,scr,mst,chr,pos);
                        
                    }
                }
                else
                    map.strutturamappa[posi][posj]->room[posx][posy]=chr.nome;
                break;
                
            }
                
            default:
                break;
        }
        
        wrefresh(win1);
    }
    
    
}


 //funzione che permette al personaggio di passare tramite la porta da una stanza ad un altra
void position::passaporta(WINDOW *win1,WINDOW *win2,WINDOW *win3, mappa map, screen scr,mostro mst,character chr, position pos){
    
   map.strutturamappa[posi][posj]->room[posx][ posy]=' ';
    map.esistestanza(win1);
    wrefresh(win1);
    
    //se la stanza successiva è stata creata sopra
    if((posx-1)==0 && posy==4){
        posi--;
        posx=5;
        posy=4;
        map.strutturamappa[posi][posj]->room[posx][ posy]=chr.nome;
         posmove(win1,win2,win3, map ,scr, mst,chr,pos);
        map.esistestanza(win1);
        
        wrefresh(win1);
    }
   //se la stanza successiva è stata creata sotto
    if((posx+1)==6 && posy==4){
        posi++;
        posx=1;
        posy=4;
        map.strutturamappa[posi][posj]->room[posx][posy]=chr.nome;
        posmove(win1,win2,win3, map ,scr,mst, chr,pos);
        
        map.esistestanza(win1);
        
        wrefresh(win1);
    }
    //se la stanza successiva è stata creata destra
    if(posx==3 && (posy+1)==8){
        posj++;
        posx=3;
        posy=1;
        map.strutturamappa[posi][posj]->room[posx][posy]=chr.nome;
        posmove(win1,win2,win3, map ,scr,mst,chr,pos);
        
        map.esistestanza(win1);
        
        wrefresh(win1);
    }
    //se la stanza successiva è stata creata sinistra
    if(posx==3 && (posy-1)==0){
        posj--;
        posx=3;
        posy=7;
        map.strutturamappa[posi][posj]->room[posx][posy]=chr.nome;
        posmove(win1,win2,win3, map, scr, mst,chr,pos);
        
        map.esistestanza(win1);
        
        wrefresh(win1);
    }

}

void position::crealivello(WINDOW *win1,WINDOW *win2, mappa map, screen scr,character chr, mostro mst, position pos){
    
    scr.statuslivello(win2,level);
    wrefresh(win2);
    bool flag[20][20];
    int c;//mi fornisce nel while il parametro di controllo per determinare il numero di stanze per livello
    
    //ciclo che crea la matrice di 0 e 1 per vedere in che punto è già presente una stanza
    for(int i=0;i<20;i++){
        for(int j=0;j<20;j++){
            if(map.strutturamappa[i][j]->room[0][0]!=' ')
                flag[i][j]=true;
            else
                flag[i][j]=false;
        }
    }
    //creo la prima stanza con il personaggio all'interno
    if(level==0){
       // generamostri(win1, map,mst,pos);
        map.istanzia(win1, posi, posj);
        map.strutturamappa[posi][posj]->room[posx][posy]=chr.nome;
        map.esistestanza(win1);
        wrefresh(win1);
        level++;
        
    }
    //per i livelli successivi prima controllo il numero di stanze che sono già state create e vado a istanziarne altre quante me ne servono in base al livello
    else if(level>= 1){
       
        
        for(int i=0;i<20;i++){
            for(int j=0;j<20;j++){
                if(flag[i][j]==true){
                    numstanza++; //numero di stanze già istanziate
                }
            }
        }
        c=level;
        while(numstanza<(c+2)){
            map.stanzasucc(win1,posi,posj);
            numstanza++;
        }
        //generachiave(win1, map, chr);
        //generamostri(win1,win2, map,mst,pos,scr,chr);
        
       map.esistestanza(win1);
        wrefresh(win1);
        level++;
        h=h+30;
        mst.attacco= mst.attacco + 50;
        mst.difesa= mst.difesa + 100;
    }
     numstanza=0;
}

//genera la chiave in una sola delle stanze generate per livello, questa funzione verrà chiamata solo quando l'utente raccoglie un tot di monete (diverso per livello)
void position::generachiave(WINDOW *win1,mappa map,character chr){
    numstanza=0;

    bool flag[20][20];
    for(int i=0;i<20;i++){
        for(int j=0;j<20;j++){
            if(map.strutturamappa[i][j]->room[0][0]!=' '){
                flag[i][j]=true;
                numstanza++;
            }
            else
                flag[i][j]=false;
        }
    }
   int r=(rand()%4+1);
    int c=(rand()%6+1);
    for(int i=0;i<20;i++){
        for(int j=0;j<20;j++){
            if(flag[i][j]==true){
                
                
                    if(numstanza==1){
                            if(map.strutturamappa[i][j]->room[r][c]==' ')
                                map.strutturamappa[i][j]->room[r][c]='j';
                            else{
                                r=(rand()%4+1);
                                c=(rand()%6+1);
                                if(map.strutturamappa[i][j]->room[r][c]==' ')
                                    map.strutturamappa[i][j]->room[r][c]='j';
                            }
                }
                    numstanza--;
            }
        }
    }
    
    chr.monete=chr.monete-h;
}

//questa funzione controlla dove è stata creata la stampa e se c'è uno spazio vuoto aggiunge i mostri(tanti quanti il num di livello)
void position::generamostri(WINDOW *win1,WINDOW *win2,mappa map, mostro mst,position pos,screen scr, character chr){
    
    srand((unsigned)time(0));
    numstanza=0;
    bool flag[20][20];
    for(int i=0;i<20;i++){
        for(int j=0;j<20;j++){
            if(map.strutturamappa[i][j]->room[0][0]!=' '){
                flag[i][j]=true;
                numstanza++;
            }
            else
                flag[i][j]=false;
        }
    }
    mst.mostrox=(rand()%4+1);
    mst.mostroy=(rand()%6+1);
    
    
   for(int i=0;i<20;i++){
        for(int j=0;j<20;j++){
            if(flag[i][j]==true){
                
                    mst.mostroi=i;
                    mst.mostroj=j;
                    if(map.strutturamappa[ mst.mostroi][mst.mostroj]->room[mst.mostrox][mst.mostroy]==' '){
                        
                        map.strutturamappa[mst.mostroi][mst.mostroj]->room[mst.mostrox][mst.mostroy]=mst.nome;
                        mst.movimento(win1,win2,map,pos,scr,chr);
                        scr.statusmostro(win2, mst.vita, mst.attacco,mst.difesa);
                        map.esistestanza(win1);
                        wrefresh(win1);
                        wrefresh(win2);
                    }
               
            }
       
   }
    }
}



    
    
void position::generaoggetti(WINDOW *win1, mappa map, oggetto ogg, position pos,character chr){

    srand((unsigned)time(0));
    bool flag[20][20];
    //numstanza=0;
    for(int i=0;i<20;i++){
        for(int j=0;j<20;j++){
            if(map.strutturamappa[i][j]->room[0][0]!=' '){
                flag[i][j]=true;
            }
            else
                flag[i][j]=false;
        }}
    ogg.oggx=(rand()%5+1);
    ogg.oggy=(rand()%7+1);
    
    if(ogg.symbol=='o'){
        int t=0;
        //t numero di monete da generare
        while((t*20)<h){
            
            for(int i=0;i<20;i++){
                for(int j=0;j<20;j++){
                    if(flag[i][j]==true){
                        if(map.strutturamappa[i][j]->room[ogg.oggx][ogg.oggy]==' '){
                            map.strutturamappa[i][j]->room[ogg.oggx][ogg.oggy]=ogg.symbol;
                            t++;
                        }
                        else
                        ogg.oggx=(rand()%5+1);
                        ogg.oggy=(rand()%7+1);
                        if(map.strutturamappa[i][j]->room[ogg.oggx][ogg.oggy]==' '){
                            map.strutturamappa[i][j]->room[ogg.oggx][ogg.oggy]=ogg.symbol;
                            t++;
                        }
                    }
                }
           }
       }
   }
   
    if(level>=4){
    if(ogg.symbol=='a'){
        for(int t=0;t<1;t++){
            for(int i=0;i<20;i++){
                for(int j=0;j<20;j++){
                    if(flag[i][j]==true){
                        if(map.strutturamappa[i][j]->room[ogg.oggx][ogg.oggy]==' '){
                            map.strutturamappa[i][j]->room[ogg.oggx][ogg.oggy]=ogg.symbol;
                            
                        }
                        else
                            ogg.oggx=(rand()%5+1);
                        ogg.oggy=(rand()%7+1);
                        if(map.strutturamappa[i][j]->room[ogg.oggx][ogg.oggy]==' '){
                            map.strutturamappa[i][j]->room[ogg.oggx][ogg.oggy]=ogg.symbol;
                        }
                    }
                }
            }

        }
        
    }
    }
   
    if(level>=6){
        if(ogg.symbol=='v'){
            for(int t=0;t<1;t++){
                for(int i=0;i<20;i++){
                    for(int j=0;j<20;j++){
                        if(flag[i][j]==true){
                            if(map.strutturamappa[i][j]->room[ogg.oggx][ogg.oggy]==' '){
                                map.strutturamappa[i][j]->room[ogg.oggx][ogg.oggy]=ogg.symbol;
                                
                            }
                            else
                                ogg.oggx=(rand()%5+1);
                                ogg.oggy=(rand()%7+1);
                            if(map.strutturamappa[i][j]->room[ogg.oggx][ogg.oggy]==' '){
                                map.strutturamappa[i][j]->room[ogg.oggx][ogg.oggy]=ogg.symbol;
                            }
                        }
                    }
                }
                
            }
            
        }
    }
    if(level>=10){
        if(chr.monete>=400){
        if(ogg.symbol=='c'){
            for(int t=0;t<1;t++){
                for(int i=0;i<20;i++){
                    for(int j=0;j<20;j++){
                        if(flag[i][j]==true){
                            if(map.strutturamappa[i][j]->room[ogg.oggx][ogg.oggy]==' '){
                                map.strutturamappa[i][j]->room[ogg.oggx][ogg.oggy]=ogg.symbol;
                                
                            }
                            else
                                ogg.oggx=(rand()%5+1);
                            ogg.oggy=(rand()%7+1);
                            if(map.strutturamappa[i][j]->room[ogg.oggx][ogg.oggy]==' '){
                                map.strutturamappa[i][j]->room[ogg.oggx][ogg.oggy]=ogg.symbol;
                            }
                        }
                    }
                }
                
            }
            
        }
    }
    }
    

}




    
    
  
