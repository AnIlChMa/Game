#ifndef MAPPA_H
#define MAPPA_H
#include "stanza.hpp"





using namespace std;
class mappa
{
    public:

        mappa();
    
        void creamappa();
        //void  stampamappa(WINDOW *win1);
        void  esistestanza(WINDOW *win1);
        std::vector<std::vector<stanza*> > strutturamappa;
        void istanzia(WINDOW *win1,int x,int y);
        void stanzasucc(WINDOW *win1, int x,int y);
        void controllo(WINDOW *win1, int x, int y);
    
};

#endif // MAPPA_H
