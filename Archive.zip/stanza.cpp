#include "stanza.hpp"
#include <iostream>

#include "Position.hpp"
#include<time.h>
#include<stdio.h>
#include<stdlib.h>
#include<string>
#include <ncurses.h>
#include <curses.h>
using namespace std;
stanza::stanza()
{
    //ptr=&room[7][7];
    //ctor
    for(int r=0;r<7;r++){
        for(int c=0;c<9;c++){
            room[r][c]=' ';
        }
    }

}

stanza::~stanza()
{
    //dtor

}
   void  stanza::creastanza(){
        for(int r=0;r<7;r++){
            for(int c=0;c<9;c++){
                 room[r][c]=' ';
            }
        }
        for(int r=0;r<7;r++){
                room[r][0]='|';
                room[r][8]='|';
                room[r][9]='\0';
        }
        for(int c=0;c<9;c++){
                room[0][c]='-';
                room[6][c]='-';
        }
        
    }



   void  stanza::stamparoom(){
         for(int i=1;i<7;i++){
            for(int j=1;j<9;j++){
                cout<<room[i][j];
            }
            cout<<endl;
         }
     }


   void stanza::wprintroom(WINDOW *win1,int x, int y){
    //cout<<"entra";
//ciclo per stampare la stanza, stampiamo come se fossero "array" di riga
                for(int r=0;r<7;r++){
                    
                   mvwprintw(win1,r+x,y,"%s",room[r]);
                }
            wrefresh(win1);
              // printf(ptr);
    }

   /*void stanza::stanzasucc(WINDOW *win1){
        srand(time(0));
        int k=(rand()%4+1);
        //senso orario

        switch(k){
        case 1:{
            room[6][4]='/';
           
        }
        break;
            case 2:{
                room[3][0]='/';
              
            }
            break;
                case 3:{
                
                }
                break;
                    case 4:{
                        room[3][8]='/';
                    
                    }
                    break;
                    default:
                        break;
        }
        wrefresh(win1);
        }*/



