#include "screen.hpp"
#include<stdlib.h>
#include<stdio.h>
#include "mappa.hpp"
#include "stanza.hpp"

screen::screen()
{
    //ctor
   // altezza=30;
    //larghezza=120;
}

screen::~screen()
{
    //dtor
}

void screen::inizializzafinestra(){
    win1=newwin(35,120,0,0);
    win2=newwin(5,120,35,0);
    //getch();

    box(win1, ACS_VLINE, ACS_HLINE);
    box(win2, ACS_VLINE, ACS_HLINE);
    refresh();

    wprintw(win2, "Status: ");
    //wprintw(win1,mappa.strutturamappa);
    wrefresh(win1);
    wrefresh(win2);
    //mvwaddchnstr(win1,1,1,mappa.strutturamappa,100);
    wrefresh(win1);
    //getch();
}

void screen::stampadentromappa(char* test){

    wmove(win1,5,5);
    //wprintw(win1,"%s",test);
    wrefresh(win1);
    getch();
}




