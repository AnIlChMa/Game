#include <iostream>
#include <cstdlib>
#include "mappa.hpp"
#include "stanza.hpp"
#include <ctime>
#include <curses.h>
#include <ncurses.h>
#include "screen.hpp"
#include "Position.hpp"
#include<vector>

using namespace std;



int main()
{
initscr();
    
    stanza bla;
    screen finestra;
                
    finestra.inizializzafinestra();
    mappa pippo;
    

    pippo.creamappa();
    
    //bla.creastanza();
    pippo.istanzia(finestra.win1,2,8);
    
    
 pippo.stanzasucc(finestra.win1);

    

   // pippo.scriviinfinestra(finestra.win1);


   pippo.esistestanza(finestra.win1);
    //bla.creaporta();
    //bla.stamparoom();
        //bla.wprintroom(finestra.win1,9,50);
   
    
    //keypad(finestra.win1, TRUE);
    //gio.posmove(finestra.win1, bla);





    refresh();
    getch();
    endwin();
    return 0;
}
