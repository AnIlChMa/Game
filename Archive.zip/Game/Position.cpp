//
//  Position.cpp
//  Game
//
//  Created by chiara mengoli on 19/10/17.
//  Copyright © 2017 chiara mengoli. All rights reserved.
//

#include "Position.hpp"
#include <curses.h>
#include <ncurses.h>
//#include "screen.hpp"




position::position(){
  
    posy=1;
    posx=1;
    posi=2;
    posj=8;
    level=1;
    numstanza=0;
    h=50;
    }

//aggiungere un parametro per indicare chi si deve spostare (personaggio/mostro)
void position::posmove(WINDOW *win1,WINDOW *win2, mappa map, screen scr,character chr){
    
    map.strutturamappa[posi][posj]->room[posx][posy]=chr.nome;
   map.esistestanza(win1);

    
    int ch= 0;
    if((ch=getch())!= 'q')
    {
        switch(ch)
        {
            case KEY_UP:{
                
                if(map.strutturamappa[posi][posj]->room[posx-1][posy] !='-'){
                    if(map.strutturamappa[posi][posj]->room[posx-1][posy] =='j'){
                        if( map.strutturamappa[posi][posj]->room[posx-1][posy] =='o' || map.strutturamappa[posi][posj]->room[posx-1][posy] =='X'){
                            chr.raccoglioggetti(win1,win2,map,pos ,scr);
                        }
                        map.strutturamappa[posi][posj]->room[posx][posy]=' ';
                        posx--;
                        map.strutturamappa[posi][posj]->room[ posx][ posy]=chr.nome;
                        crealivello(win1,win2, map,scr,chr);
                        
                    }
                    if(map.strutturamappa[posi][posj]->room[posx-1][posy] =='/' ){
                        passaporta(win1,win2, map ,scr,chr);
                    
                        }
                    if(map.strutturamappa[posi][posj]->room[posx-1][posy] ==' '){
                        map.strutturamappa[posi][posj]->room[posx][posy]=' ';
                        posx--;
                        map.strutturamappa[posi][posj]->room[ posx][ posy]=chr.nome;
                        map.esistestanza(win1);
                }
                }
                else
                    map.strutturamappa[posi][posj]->room[posx][posy]=chr.nome;
                break;
                            }
                
            case KEY_DOWN:{
               
                if(map.strutturamappa[posi][posj]->room[posx+1][posy] !='-' ){
                    if(map.strutturamappa[posi][posj]->room[posx+1][posy] =='j'){
                        if( map.strutturamappa[posi][posj]->room[posx+1][posy] =='o' || map.strutturamappa[posi][posj]->room[posx+1][posy] =='X'){
                            chr.raccoglioggetti(win1,win2,map,pos,scr);
                        }

                        map.strutturamappa[posi][posj]->room[ posx][ posy]=' ';
                        posx++;
                        
                        map.strutturamappa[posi][posj]->room[ posx][ posy]=chr.nome;
                         crealivello(win1,win2, map,scr,chr);
                        
                    }
                    if(map.strutturamappa[posi][posj]->room[posx+1][posy] =='/' ){
                        passaporta(win1,win2, map ,scr, chr);
                       

                    }
                    if(map.strutturamappa[posi][posj]->room[posx+1][posy] ==' '){
                        map.strutturamappa[posi][posj]->room[ posx][ posy]=' ';
                        posx++;
                
                        map.strutturamappa[posi][posj]->room[ posx][ posy]=chr.nome;
                        map.esistestanza(win1);
                        }
                }
                else
                    map.strutturamappa[posi][posj]->room[posx][posy]=chr.nome;
                break;
                
            }
                
            case KEY_RIGHT:{
                        if (map.strutturamappa[posi][posj]->room[posx][posy+1]!='|'){
                            if(map.strutturamappa[posi][posj]->room[posx][posy+1] =='j'){
                                if( map.strutturamappa[posi][posj]->room[posx][posy+1] =='o' || map.strutturamappa[posi][posj]->room[posx][posy+1] =='X'){
                                    chr.raccoglioggetti(win1,win2,map,pos,scr);
                                }

                                map.strutturamappa[posi][posj]->room[ posx][ posy]=' ';
                                posy++;
                                
                                map.strutturamappa[posi][posj]->room[ posx][ posy]=chr.nome;
                                crealivello(win1,win2, map,scr,chr);
                                
                                    }
                    if(map.strutturamappa[posi][posj]->room[posx][posy+1] =='/' ){
                        passaporta(win1,win2, map ,scr,chr);
                                            }
                    if(map.strutturamappa[posi][posj]->room[posx][posy+1] ==' '){
                        map.strutturamappa[posi][posj]->room[ posx][ posy]=' ';
                        posy++;
                
                        map.strutturamappa[posi][posj]->room[ posx][ posy]=chr.nome;
                        map.esistestanza(win1);
                    }
                }
                else
                    map.strutturamappa[posi][posj]->room[posx][posy]=chr.nome;
                break;
                
            }
                
            case KEY_LEFT:{
                

                if(map.strutturamappa[posi][posj]->room[posx][posy-1]!='|'){
                    if(map.strutturamappa[posi][posj]->room[posx][posy-1] =='j'){
                        if( map.strutturamappa[posi][posj]->room[posx][posy-1] =='o' || map.strutturamappa[posi][posj]->room[posx][posy-1] =='X'){
                            chr.raccoglioggetti(win1,win2,map,pos,scr);
                        }

                        map.strutturamappa[posi][posj]->room[ posx][ posy]=' ';
                        posy--;
                        
                        map.strutturamappa[posi][posj]->room[ posx][ posy]=chr.nome;
                        crealivello(win1,win2, map,scr,chr);
                        

                    }
                    if(map.strutturamappa[posi][posj]->room[posx][posy-1] =='/' ){
                        passaporta(win1,win2, map ,scr,chr);
                        
                    }
                    if(map.strutturamappa[posi][posj]->room[posx][posy-1] ==' '){
                        map.strutturamappa[posi][posj]->room[ posx][ posy]=' ';
                        posy--;
                
                        map.strutturamappa[posi][posj]->room[ posx][ posy]=chr.nome;
                        map.esistestanza(win1);
                    }
                }
                else
                    map.strutturamappa[posi][posj]->room[posx][posy]=chr.nome;
                break;
                
            }
                
            default:
                break;
        }
        
        wrefresh(win1);
    }
    
    
}


 //funzione che permette al personaggio di passare tramite la porta da una stanza ad un altra
void position::passaporta(WINDOW *win1,WINDOW *win2, mappa map, screen scr, character chr){
    
    map.strutturamappa[posi][posj]->room[posx][ posy]=' ';
    map.esistestanza(win1);
    wrefresh(win1);
    
    //se la stanza successiva è stata creata sopra
    if((posx-1)==0 && posy==4){
        posi--;
        posx=5;
        posy=4;
        map.strutturamappa[posi][posj]->room[posx][ posy]=chr.nome;
         posmove(win1,win2, map ,scr, chr);
        map.esistestanza(win1);
        
        wrefresh(win1);
    }
   //se la stanza successiva è stata creata sotto
    if((posx+1)==6 && posy==4){
        posi++;
        posx=1;
        posy=4;
        map.strutturamappa[posi][posj]->room[posx][posy]=chr.nome;
        posmove(win1,win2, map ,scr, chr);
        map.esistestanza(win1);
        
        wrefresh(win1);
    }
    //se la stanza successiva è stata creata destra
    if(posx==3 && (posy+1)==8){
        posj++;
        posx=3;
        posy=1;
        map.strutturamappa[posi][posj]->room[posx][posy]=chr.nome;
        posmove(win1,win2, map ,scr,chr);
        map.esistestanza(win1);
        
        wrefresh(win1);
    }
    //se la stanza successiva è stata creata sinistra
    if(posx==3 && (posy-1)==0){
        posj--;
        posx=3;
        posy=7;
        map.strutturamappa[posi][posj]->room[posx][posy]=chr.nome;
        posmove(win1,win2, map, scr, chr);
        map.esistestanza(win1);
        
        wrefresh(win1);
    }

}

void position::crealivello(WINDOW *win1,WINDOW *win2, mappa map, screen scr,character chr){
 
    scr.statuslivello(win2,level);
    wrefresh(win2);
    bool flag[20][20];
    int c;//mi fornisce nel while il parametro di controllo per determinare il numero di stanze per livello
    
    //ciclo che crea la matrice di 0 e 1 per vedere in che punto è già presente una stanza
    for(int i=0;i<20;i++){
        for(int j=0;j<20;j++){
            if(map.strutturamappa[i][j]->room[0][0]!=' ')
                flag[i][j]=true;
            else
                flag[i][j]=false;
        }
    }
    //creo la prima stanza con il personaggio all'interno
    if(level==1){
        
        map.istanzia(win1, posi, posj);
        map.strutturamappa[posi][posj]->room[posx][posy]=chr.nome;
        generachiave(win1, map);
        map.esistestanza(win1);
        wrefresh(win1);
        level++;
        h=h*2;
    }
    //per i livelli successivi prima controllo il numero di stanze che sono già state create e vado a istanziarne altre quante me ne servono in base al livello
    else if(level!= 1){
       
        
        for(int i=0;i<20;i++){
            for(int j=0;j<20;j++){
                if(flag[i][j]==true){
                    numstanza++; //numero di stanze già istanziate
                }
            }
        }
        c=level;
        while(numstanza<(c+1)){
            
            map.stanzasucc(win1,posi,posj);
            numstanza++;
        }
        numstanza=0;
       generachiave(win1, map);
         
       map.esistestanza(win1);
        wrefresh(win1);
        level++;
        h=h*2;
        
    }
     numstanza=0;
}

//genera la chiave in una sola delle stanze generate per livello, questa funzione verrà chiamata solo quando l'utente raccoglie un tot di monete (diverso per livello)
void position::generachiave(WINDOW *win1,mappa map){
    numstanza=0;

    bool flag[20][20];
    for(int i=0;i<20;i++){
        for(int j=0;j<20;j++){
            if(map.strutturamappa[i][j]->room[0][0]!=' '){
                flag[i][j]=true;
                numstanza++;
            }
            else
                flag[i][j]=false;
        }
    }
    srand((unsigned)time(0));
    int r=(rand()%5+1); //numero random che indica la riga per le coordinate della chiave
    int c=(rand()%7+1);//numero random che indica la colonna per le coordinate della chiave
    for(int i=0;i<20;i++){
        for(int j=0;j<20;j++){
            if(flag[i][j]==true){
                
                if(numstanza==1){   //se numstanza==1 indica che sono nell'ultima stanza generata
                    map.strutturamappa[i][j]->room[r][c]='j';
                }
                
                numstanza--;
            }
        }
    }
    
                            
}


    
    
    
    
    





    
    
  
