//
//  Position.cpp
//  Game
//
//  Created by chiara mengoli on 19/10/17.
//  Copyright © 2017 chiara mengoli. All rights reserved.
//

#include "Position.hpp"
#include <curses.h>
#include <ncurses.h>
#include "mappa.hpp"


position::position(){
    a[0]='@';
    posy=1;
    posx=1;
}

void position::posmove(WINDOW *win1, mappa map,int i, int j){
    
    map.strutturamappa[i][j]->room[posx][posy]=a[0];
    map.esistestanza(win1);

    
    int ch= 0;
    if((ch=getch())!= 'q')
    {
        switch(ch)
        {
            case KEY_UP:{
                
                if(map.strutturamappa[i][j]->room[posx-1][posy] !='-'){
                    if(map.strutturamappa[i][j]->room[posx-1][posy] =='j'){
                        map.strutturamappa[i][j]->room[posx][posy]=' ';
                        posx--;
                        map.strutturamappa[i][j]->room[ posx][ posy]='@';
                        crealivello(win1, map, i, j);
                    }
                    if(map.strutturamappa[i][j]->room[posx-1][posy] =='/' ){
                        passaporta(win1,map,i,j);
                    
                    }
                    else{
                map.strutturamappa[i][j]->room[posx][posy]=' ';
                 posx--;
                map.strutturamappa[i][j]->room[ posx][ posy]='@';
                map.esistestanza(win1);
                }
                }
                else
                    map.strutturamappa[i][j]->room[posx][posy]='@';
                break;
                            }
                
            case KEY_DOWN:{
               
                if(map.strutturamappa[i][j]->room[posx+1][posy] !='-' ){
                    if(map.strutturamappa[i][j]->room[posx+1][posy] =='j'){
                       
                        map.strutturamappa[i][j]->room[ posx][ posy]=' ';
                        posx++;
                        
                        map.strutturamappa[i][j]->room[ posx][ posy]='@';
                         crealivello(win1, map, i, j);
                    }
                    if(map.strutturamappa[i][j]->room[posx+1][posy] =='/' ){
                        passaporta(win1,map,i,j);
                       

                    }
                        else{
                map.strutturamappa[i][j]->room[ posx][ posy]=' ';
                 posx++;
                
                map.strutturamappa[i][j]->room[ posx][ posy]='@';
                map.esistestanza(win1);
                        }
                }
                else
                    map.strutturamappa[i][j]->room[posx][posy]='@';
                break;
                
            }
                
            case KEY_RIGHT:{
                        if (map.strutturamappa[i][j]->room[posx][posy+1]!='|'){
                            if(map.strutturamappa[i][j]->room[posx][posy+1] =='j'){
                                
                                map.strutturamappa[i][j]->room[ posx][ posy]=' ';
                                posy++;
                                
                                map.strutturamappa[i][j]->room[ posx][ posy]='@';
                                crealivello(win1, map, i, j);
                                    }
                    if(map.strutturamappa[i][j]->room[posx][posy+1] =='/' ){
                        passaporta(win1,map,i,j);
                                            }
                    else{
                map.strutturamappa[i][j]->room[ posx][ posy]=' ';
                 posy++;
                
                map.strutturamappa[i][j]->room[ posx][ posy]='@';
                map.esistestanza(win1);
                    }
                }
                else
                    map.strutturamappa[i][j]->room[posx][posy]='@';
                break;
                
            }
                
            case KEY_LEFT:{
                

                if(map.strutturamappa[i][j]->room[posx][posy-1]!='|'){
                    if(map.strutturamappa[i][j]->room[posx][posy-1] =='j'){
                        
                        map.strutturamappa[i][j]->room[ posx][ posy]=' ';
                        posy--;
                        
                        map.strutturamappa[i][j]->room[ posx][ posy]='@';
                        crealivello(win1, map, i, j);

                    }
                    if(map.strutturamappa[i][j]->room[posx][posy-1] =='/' ){
                        passaporta(win1,map,i,j);
                        
                    }
                    else{
                map.strutturamappa[i][j]->room[ posx][ posy]=' ';
                 posy--;
                
                map.strutturamappa[i][j]->room[ posx][ posy]='@';
                map.esistestanza(win1);
                    }
                }
                else
                    map.strutturamappa[i][j]->room[posx][posy]='@';
                break;
                
            }
                
            default:
                break;
        }
        
        wrefresh(win1);
    }
    
    
}


        
void position::passaporta(WINDOW *win1,mappa map, int i, int j){
    
    map.strutturamappa[i][j]->room[ posx][ posy]=' ';
    map.esistestanza(win1);
    wrefresh(win1);
    
    //se la stanza successiva è stata creata sopra
    if((posx-1)==0 && posy==4){
        i--;
        posx=5;
        posy=4;
        map.strutturamappa[i][j]->room[posx][ posy]='@';
        map.esistestanza(win1);
        posmove(win1, map, i, j);
        wrefresh(win1);
    }
   //se la stanza successiva è stata creata sotto
    if((posx+1)==6 && posy==4){
        i++;
        posx=1;
        posy=4;
        map.strutturamappa[i][j]->room[posx][posy]='@';
        map.esistestanza(win1);
        posmove(win1, map, i, j);
        wrefresh(win1);
    }
    //se la stanza successiva è stata creata destra
    if(posx==3 && (posy+1)==8){
        j++;
        posx=3;
        posy=1;
        map.strutturamappa[i][j]->room[posx][posy]='@';
        map.esistestanza(win1);
        posmove(win1, map, i, j);
        wrefresh(win1);
    }
    //se la stanza successiva è stata creata sinistra
    if(posx==3 && (posy-1)==0){
        j--;
        posx=3;
        posy=7;
        map.strutturamappa[i][j]->room[posx][posy]='@';
        map.esistestanza(win1);
        posmove(win1, map, i, j);
        wrefresh(win1);
    }

}

void position::crealivello(WINDOW *win1,mappa map, int i, int j){
    ptr_level p;
    p->nstanza=1;
    map.stanzasucc(win1);
    wrefresh(win1);
    p->nstanza=p->nstanza*2;
    p->num++;
    
}
    

    
    
    
  
