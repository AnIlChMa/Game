//
//  Position.cpp
//  Game
//
//  Created by chiara mengoli on 19/10/17.
//  Copyright © 2017 chiara mengoli. All rights reserved.
//

#include "Position.hpp"
#include <curses.h>
#include <ncurses.h>
#include "mappa.hpp"


position::position(){
    a[0]='@';
    posy=1;
    posx=1;
    posi=2;
    posj=8;
    level=1;
    numstanza=1;
}

//aggiungere un parametro per indicare chi si deve spostare (personaggio/mostro)
void position::posmove(WINDOW *win1, mappa map){
    
    map.strutturamappa[posi][posj]->room[posx][posy]=a[0];
   map.esistestanza(win1);

    
    int ch= 0;
    if((ch=getch())!= 'q')
    {
        switch(ch)
        {
            case KEY_UP:{
                
                if(map.strutturamappa[posi][posj]->room[posx-1][posy] !='-'){
                    if(map.strutturamappa[posi][posj]->room[posx-1][posy] =='j'){
                        map.strutturamappa[posi][posj]->room[posx][posy]=' ';
                        posx--;
                        map.strutturamappa[posi][posj]->room[ posx][ posy]='@';
                        //crealivello(win1, map);
                        map.stanzasucc(win1, posi, posj);
                    }
                    if(map.strutturamappa[posi][posj]->room[posx-1][posy] =='/' ){
                        passaporta(win1,map);
                    
                    }
                    else{
                map.strutturamappa[posi][posj]->room[posx][posy]=' ';
                 posx--;
                map.strutturamappa[posi][posj]->room[ posx][ posy]='@';
                map.esistestanza(win1);
                }
                }
                else
                    map.strutturamappa[posi][posj]->room[posx][posy]='@';
                break;
                            }
                
            case KEY_DOWN:{
               
                if(map.strutturamappa[posi][posj]->room[posx+1][posy] !='-' ){
                    if(map.strutturamappa[posi][posj]->room[posx+1][posy] =='j'){
                       
                        map.strutturamappa[posi][posj]->room[ posx][ posy]=' ';
                        posx++;
                        
                        map.strutturamappa[posi][posj]->room[ posx][ posy]='@';
                         //crealivello(win1, map);
                        map.stanzasucc(win1, posi, posj);
                    }
                    if(map.strutturamappa[posi][posj]->room[posx+1][posy] =='/' ){
                        passaporta(win1,map);
                       

                    }
                        else{
                map.strutturamappa[posi][posj]->room[ posx][ posy]=' ';
                 posx++;
                
                map.strutturamappa[posi][posj]->room[ posx][ posy]='@';
                map.esistestanza(win1);
                        }
                }
                else
                    map.strutturamappa[posi][posj]->room[posx][posy]='@';
                break;
                
            }
                
            case KEY_RIGHT:{
                        if (map.strutturamappa[posi][posj]->room[posx][posy+1]!='|'){
                            if(map.strutturamappa[posi][posj]->room[posx][posy+1] =='j'){
                                
                                map.strutturamappa[posi][posj]->room[ posx][ posy]=' ';
                                posy++;
                                
                                map.strutturamappa[posi][posj]->room[ posx][ posy]='@';
                                //crealivello(win1, map);
                                map.stanzasucc(win1, posi, posj);
                                    }
                    if(map.strutturamappa[posi][posj]->room[posx][posy+1] =='/' ){
                        passaporta(win1,map);
                                            }
                    else{
                map.strutturamappa[posi][posj]->room[ posx][ posy]=' ';
                 posy++;
                
                map.strutturamappa[posi][posj]->room[ posx][ posy]='@';
                map.esistestanza(win1);
                    }
                }
                else
                    map.strutturamappa[posi][posj]->room[posx][posy]='@';
                break;
                
            }
                
            case KEY_LEFT:{
                

                if(map.strutturamappa[posi][posj]->room[posx][posy-1]!='|'){
                    if(map.strutturamappa[posi][posj]->room[posx][posy-1] =='j'){
                        
                        map.strutturamappa[posi][posj]->room[ posx][ posy]=' ';
                        posy--;
                        
                        map.strutturamappa[posi][posj]->room[ posx][ posy]='@';
                        //crealivello(win1, map);
                        map.stanzasucc(win1, posi, posj);

                    }
                    if(map.strutturamappa[posi][posj]->room[posx][posy-1] =='/' ){
                        passaporta(win1,map);
                        
                    }
                    else{
                map.strutturamappa[posi][posj]->room[ posx][ posy]=' ';
                 posy--;
                
                map.strutturamappa[posi][posj]->room[ posx][ posy]='@';
                map.esistestanza(win1);
                    }
                }
                else
                    map.strutturamappa[posi][posj]->room[posx][posy]='@';
                break;
                
            }
                
            default:
                break;
        }
        
        wrefresh(win1);
    }
    
    
}


        
void position::passaporta(WINDOW *win1,mappa map){
    
    map.strutturamappa[posi][posj]->room[posx][ posy]=' ';
    map.esistestanza(win1);
    wrefresh(win1);
    
    //se la stanza successiva è stata creata sopra
    if((posx-1)==0 && posy==4){
        posi--;
        posx=5;
        posy=4;
        map.strutturamappa[posi][posj]->room[posx][ posy]='@';
         posmove(win1, map);
        map.esistestanza(win1);
        
        wrefresh(win1);
    }
   //se la stanza successiva è stata creata sotto
    if((posx+1)==6 && posy==4){
        posi++;
        posx=1;
        posy=4;
        map.strutturamappa[posi][posj]->room[posx][posy]='@';
        posmove(win1, map);
        map.esistestanza(win1);
        
        wrefresh(win1);
    }
    //se la stanza successiva è stata creata destra
    if(posx==3 && (posy+1)==8){
        posj++;
        posx=3;
        posy=1;
        map.strutturamappa[posi][posj]->room[posx][posy]='@';
        posmove(win1, map);
        map.esistestanza(win1);
        
        wrefresh(win1);
    }
    //se la stanza successiva è stata creata sinistra
    if(posx==3 && (posy-1)==0){
        posj--;
        posx=3;
        posy=7;
        map.strutturamappa[posi][posj]->room[posx][posy]='@';
        posmove(win1, map);
        map.esistestanza(win1);
        
        wrefresh(win1);
    }

}

void position::crealivello(WINDOW *win1, mappa map){
    bool flag[20][20];
   
    
    //ciclo che crea la matrice di 0 e 1 per vedere in che punto è già presente una stanza
    for(int i=0;i<20;i++){
        for(int j=0;j<20;j++){
            if(map.strutturamappa[i][j]->room[0][0]!=' ')
                flag[i][j]=true;
            else
                flag[i][j]=false;
        }
    }
    int x=1;
    
    switch(level){
                case 1:
                {
                   
                    map.istanzia(win1, posi, posj);
                    map.strutturamappa[posi][posj]->room[posx][posy]=a[0];
                    map.esistestanza(win1);
                    level++;
                     h=h*2;
                    numstanza=numstanza+2;
                    posmove(win1, map);
                                    }
                    break;
                case 2:
                {
                    
                       while(x<numstanza){
                            map.stanzasucc(win1,posi,posj);
                           x++;
                           
                        }
                    
                    level++;
                     h=h*2;
                    numstanza=numstanza+2;
                       posmove(win1, map);
                        }
                    break;
        case 3:
        {
            
            while(x<numstanza){
                map.stanzasucc(win1,posi,posj);
                x++;
                
            }
            
            level++;
            h=h*2;
            numstanza=numstanza+2;
               posmove(win1, map);
        }
            break;
        case 4:
        {
            
            while(x<numstanza){
                map.stanzasucc(win1,posi,posj);
                x++;
                
            }
            
            level++;
            h=h*2;
            numstanza=numstanza+2;
               posmove(win1, map);
        }
            break;
        case 5:
        {
            
            while(x<numstanza){
                map.stanzasucc(win1,posi,posj);
                x++;
                
            }
            
            level++;
            h=h*2;
            numstanza=numstanza+2;
               posmove(win1, map);
        }
            break;



                default:
                    {
                        while(x<numstanza){
                            map.stanzasucc(win1, posi, posj);
                            x++;
                        }
            
                        level++;
                        h=h*2;
                        numstanza=numstanza+2;
                           posmove(win1, map);
                        break;
                    }
        }

    }





    
    
    
    
    





    
    
  
