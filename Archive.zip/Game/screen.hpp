#ifndef SCREEN_H
#define SCREEN_H
#include <curses.h>
#include <ncurses.h>
//#include "Position.hpp"
class screen
{
    public:
        screen();
        virtual ~screen();
       void inizializzafinestra();
     WINDOW *win1, *win2, *win3;
    void statuslivello(WINDOW *win2 ,int level);
    void statusvita(WINDOW *win2 ,int vita);
};

#endif // SCREEN_H


