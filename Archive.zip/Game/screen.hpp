#ifndef SCREEN_H
#define SCREEN_H
#include <curses.h>
#include <ncurses.h>

class screen
{
    public:
        screen();
        virtual ~screen();
       void inizializzafinestra();
     WINDOW *win1, *win2, *win3;
    void statuslivello(WINDOW *win2 ,int level);
    void statusvita(WINDOW *win2 ,int vita);
    void  statusmonete(WINDOW *win1, int monete);
    void listaoggetti(WINDOW *win3, char nome);
    int r;
   
};

#endif // SCREEN_H


