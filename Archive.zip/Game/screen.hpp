#ifndef SCREEN_H
#define SCREEN_H
#include <curses.h>
#include <ncurses.h>

class screen
{
    public:
        screen();
        virtual ~screen();
       void inizializzafinestra();
     WINDOW *win1, *win2;

};

#endif // SCREEN_H


