#include "screen.hpp"
#include<stdlib.h>
#include<stdio.h>
#include "mappa.hpp"
#include "stanza.hpp"

screen::screen()
{
   
}

screen::~screen()
{
    //dtor
}
//funzione che crea due sottofinestre win1 per il gioco e win2 per il menù e gli mette un bordo ad entrambe
void screen::inizializzafinestra(){
    win1=newwin(35,120,0,0);
    win2=newwin(5,120,35,0);
    //getch();

    box(win1, ACS_VLINE, ACS_HLINE);
    box(win2, ACS_VLINE, ACS_HLINE);
    refresh();

    wprintw(win2, "Status: ");
    //wprintw(win1,mappa.strutturamappa);
    wrefresh(win1);
    wrefresh(win2);
    //mvwaddchnstr(win1,1,1,mappa.strutturamappa,100);
    wrefresh(win1);
    //getch();
}



