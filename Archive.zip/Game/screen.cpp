#include "screen.hpp"
#include<stdlib.h>
#include<stdio.h>
#include "mappa.hpp"
#include "stanza.hpp"

screen::screen()
{
    r=2;
    
}

screen::~screen()
{
    //dtor
}
//funzione che crea due sottofinestre win1 per il gioco e win2 per il menù e gli mette un bordo ad entrambe
void screen::inizializzafinestra(){
    getch();
    win1=newwin(40,160,0,0);
    win2=newwin(8,160,40,0);
    win3=newwin(48,20,0,160);
    //getch();

    box(win1, ACS_VLINE, ACS_HLINE);
    box(win2, ACS_VLINE, ACS_HLINE);
    box(win3, ACS_VLINE, ACS_HLINE);
    refresh();

    wprintw(win2, "Status: ");
    wprintw(win3, "Oggetti: ");
   
    
    wrefresh(win2);
    wrefresh(win3);
    
}


void screen::statuslivello(WINDOW *win2,int level){
    mvwprintw(win2,2,2, "%s", "LIVELLO:");
    mvwprintw(win2,2,11, "%d", level);
    wrefresh(win2);
}

void screen::statuspersonaggio(WINDOW *win2, int vita,int attacco,int difesa){
    mvwprintw(win2,3,2, "%s", "Anni di vita che ti rimangono:");
    mvwprintw(win2,3,32, "%s","    ");
    mvwprintw(win2,3,32, "%d",vita);
    mvwprintw(win2,4,2, "%s", "Attacco:");
    mvwprintw(win2,4,11, "%s","     ");
    mvwprintw(win2,4,11, "%d",attacco);
    mvwprintw(win2,5,2, "%s", "Difesa:");
    mvwprintw(win2,5,9, "%s","    ");
    mvwprintw(win2,5,9, "%d",difesa);
    wrefresh(win2);
}

void screen::statusmonete(WINDOW *win2, int monete){
    mvwprintw(win2,2,14, "%s", "Dolcetti raccolti:");
    mvwprintw(win2,2,33, "%d", monete);
    wrefresh(win2);
    
}
void screen::statusmostro(WINDOW *win2, int vita,int attacco,int difesa){
    mvwprintw(win2,3,40, "%s", "Vita Mostro:");
    mvwprintw(win2,3,52, "%s","     ");
    mvwprintw(win2,3,52, "%d",vita);
    
    mvwprintw(win2,4,40, "%s", "Attacco:");
    mvwprintw(win2,4,52, "%s","     ");
    mvwprintw(win2,4,52, "%d",attacco);
    
    mvwprintw(win2,5,40, "%s", "Difesa:");
    mvwprintw(win2,5,52, "%s","     ");
    mvwprintw(win2,5,52, "%d",difesa);
    
    wrefresh(win2);
}

void screen::stampaoggetti(WINDOW *win3,char ogg[11]){
    //for(int x=2;x<12;x++){
    int x=2;
    for(int r=0;r<10;r++){
        mvwprintw(win3, x, 3, "%c",ogg[r]);
         wrefresh(win3);
        x++;
    }
    
   
}
