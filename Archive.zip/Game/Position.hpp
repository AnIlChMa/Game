//
//  Position.hpp
//  Game
//
//  Created by chiara mengoli on 19/10/17.
//  Copyright © 2017 chiara mengoli. All rights reserved.
//

#ifndef Position_hpp
#define Position_hpp

#include <stdio.h>
#include <curses.h>
#include <ncurses.h>
#include "mappa.hpp"
#include "character.hpp"


class position {
    
    
public:
    position();
    
    void posmove(WINDOW *win1,WINDOW *win2,mappa map, screen scr, character chr, position pos);
    void passaporta(WINDOW *win1,WINDOW *win2, mappa map, screen scr,character chr, position pos);
     void crealivello(WINDOW *win1,WINDOW *win2,mappa map, screen scr, character chr);
    void generachiave(WINDOW *win1,mappa map);
    int posx;
    int posy;
    int posi;
    int posj;
    int level;
    int ch;
    char main_char='@';
    int h;//valore di monete che permette la comparsa della chiave in una stanza per accedere al livello successivo
protected:
    int numstanza;
    
};
#endif /* Position_hpp */
