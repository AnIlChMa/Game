//
//  Position.hpp
//  Game
//
//  Created by chiara mengoli on 19/10/17.
//  Copyright © 2017 chiara mengoli. All rights reserved.
//

#ifndef Position_hpp
#define Position_hpp

#include <stdio.h>
#include <curses.h>
#include <ncurses.h>
#include "mappa.hpp"
#include "stanza.hpp"
class position {
    
    
public:
    position();
    
    void posmove(WINDOW *win1, mappa map);
    void passaporta(WINDOW *win1,mappa map);
     void crealivello(WINDOW *win1,mappa map);
    int level;
private:
    char a[1];
    int posx;
    int posy;
    int posi;
    int posj;
    int h; //valore di monete che permette la comparsa della chiave in una stanza per accedere al livello successivo
    int numstanza;
    /*struct level{
        int num;
        int nstanza;
        level *next;
    };
    typedef level *ptr_level;
    ptr_level p;*/
    
};
#endif /* Position_hpp */
