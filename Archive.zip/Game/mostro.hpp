//
//  mostro.hpp
//  Game
//
//  Created by chiara mengoli on 25/10/17.
//  Copyright © 2017 chiara mengoli. All rights reserved.
//

#ifndef mostro_hpp
#define mostro_hpp

#include <stdio.h>
#include "character.hpp"

class mostro : public character {
    mostro();
    void battaglia(WINDOW *win1);
public:
    
};



#endif /* mostro_hpp */
