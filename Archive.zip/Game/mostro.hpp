//
//  mostro.hpp
//  Game
//
//  Created by chiara mengoli on 25/10/17.
//  Copyright © 2017 chiara mengoli. All rights reserved.
//

#ifndef mostro_hpp
#define mostro_hpp

#include <stdio.h>
#include "mappa.hpp"
#include "screen.hpp"
#include "character.hpp"



class position;

class mostro: public character{
    public:
    mostro();
    void battaglia(WINDOW *win1,WINDOW *win2, screen scr);
  void movimento(WINDOW *win1, mappa map, position pos, int i, int j);
    void inseriscimostro(WINDOW *win1, mappa map, position pos);

    
};



#endif /* mostro_hpp */
