#include <iostream>
#include <cstdlib>
#include "mappa.hpp"
#include "stanza.hpp"
#include <ctime>
#include <curses.h>
#include <ncurses.h>
#include "screen.hpp"
#include "Position.hpp"
#include<vector>
#include "character.hpp"
#include "mostro.hpp"
using namespace std;



int main()
{
initscr();
    
    stanza bla;
    screen finestra;
    position pos;
    finestra.inizializzafinestra();
    mappa pippo;
    character chr;
    mostro mst;
    pippo.creamappa();
    mst.inseriscimostro(finestra.win1, pippo, pos);
    //bla.creastanza();
   // pippo.istanzia(finestra.win1,2,8);
    // pippo.esistestanza(finestra.win1);
    pos.crealivello(finestra.win1,finestra.win2, pippo, finestra,chr.nome);
    mst.movimento(finestra.win1, pippo, pos, 5, 3);
   //pippo.stanzasucc(finestra.win1);
   bool v= chr.vivo(finestra.win2, finestra);
   keypad(stdscr, TRUE);
    
    while(v){
   pos.posmove(finestra.win1,finestra.win2, pippo, finestra,chr.nome);
    }
    
    // pos.crealivello(finestra.win1, pippo, 2, 8);
   //pippo.stanzasucc(finestra.win1);
   // pippo.scriviinfinestra(finestra.win1);


   
    //bla.creaporta();
        //bla.wprintroom(finestra.win1,9,50);



   
    getch();
    endwin();
    return 0;
}
