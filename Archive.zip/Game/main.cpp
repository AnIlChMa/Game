#include <iostream>
#include <cstdlib>
#include "mappa.hpp"
#include "stanza.hpp"
#include <ctime>
#include <curses.h>
#include <ncurses.h>
#include "screen.hpp"
#include "Position.hpp"
#include <vector>
#include "character.hpp"
#include "mostro.hpp"
#include "oggetto.hpp"
using namespace std;



int main()
{
initscr();
    
    stanza bla;
    screen finestra;
    position posit;
    finestra.inizializzafinestra();
    mappa pippo;
    character chr;
    mostro mst;
    oggetto moneta('o',"moneta");
    
    oggetto arma ('a',"arma"); //l'arma se usata aumenta la potenza d'attacco del personaggio
    
    oggetto chiave('j',"chiave");
    
    oggetto vita('v',"vita");//l'oggetto vita se usata aumenta la vita del personaggio
    pippo.creamappa();
    
    finestra.statusmonete(finestra.win2, chr.monete);
    //finestra.statusmostro(finestra.win2, mst.vita);
    
    posit.crealivello(finestra.win1,finestra.win2, pippo, finestra,chr,mst,posit);
   
    posit.generaoggetti(finestra.win1, pippo, moneta, posit);
    posit.generaoggetti(finestra.win1, pippo, arma, posit);
    posit.generaoggetti(finestra.win1, pippo, vita, posit);
    
   bool f= chr.vivo(finestra.win2, finestra);
    
   keypad(stdscr, TRUE);
    
    while(f){
   posit.posmove(finestra.win1,finestra.win2,finestra.win3, pippo, finestra,mst, chr,posit);
        
    }
    chr.usaoggetti(finestra.win1,finestra.win3, pippo, posit,finestra );
    // pos.crealivello(finestra.win1, pippo, 2, 8);
   //pippo.stanzasucc(finestra.win1);
   // pippo.scriviinfinestra(finestra.win1);


   
    //bla.creaporta();
        //bla.wprintroom(finestra.win1,9,50);



   
    getch();
    endwin();
    return 0;
}
