//
//  mostro.cpp
//  Game
//
//  Created by chiara mengoli on 25/10/17.
//  Copyright © 2017 chiara mengoli. All rights reserved.
//

#include "mostro.hpp"
#include "screen.hpp"
mostro::mostro(){
 
}



void mostro::battaglia(WINDOW *win1){

//controllo che ci sia vita
    if (character::vita>0){
        //se l'attacco del personaggi è minore della difesa del mostro tolgo vita al personaggio altrimnti al mostro
        int k=(character::attacco)-(difesa);
        character::vita=character::vita-(k*0.1);
        vivo();}
    
}

