//
//  mostro.cpp
//  Game
//
//  Created by chiara mengoli on 25/10/17.
//  Copyright © 2017 chiara mengoli. All rights reserved.
//

#include "mostro.hpp"
#include <math.h>

mostro::mostro(){
   nome='M';
}



void mostro::battaglia(WINDOW *win1,WINDOW *win2, screen scr ){

//controllo che ci sia vita
    if (character::vita>0){
        //se l'attacco del personaggi è minore della difesa del mostro tolgo vita al personaggio altrimnti al mostro
        int k=(character::attacco)-(difesa);
        character::vita=character::vita-(k*0.1);
        scr.statusvita(win2, character::vita);
        vivo(win2,scr);
    }
    
}

void mostro::movimento(WINDOW *win1, mappa map, position pos, int i, int j){
    
    //i,j posizione del mostro 
    int poss = -1;
    int score=(pos.posx)^2 +(pos.posy)^2;
    int dist= -1;
    
    //si muove verso sinistra
    if(map.strutturamappa[pos.posi][pos.posj]->room[pos.posx][pos.posy-1]==' '){
        
        dist= pow(i-pos.posx,2)+ pow(j-pos.posy,2);
        if(score>dist){
            score=dist;
            poss=0;
        }
        wrefresh(win1);
    }
    //si muove verso destra
    if(map.strutturamappa[pos.posi][pos.posj]->room[pos.posx][pos.posy+1]==' '){
        dist= pow(i-pos.posx,2)+ pow(j-pos.posy,2);
        if(score>dist){
            score=dist;
            poss=1;
        }
        wrefresh(win1);
    }
    //si muove verso l'alto
    if(map.strutturamappa[pos.posi][pos.posj]->room[pos.posx-1][pos.posy]==' '){
        dist= pow(i-pos.posx,2)+ pow(j-pos.posy,2);
        if(score>dist){
            score=dist;
            poss=2;
        }
        wrefresh(win1);
    }
    //si muove verso il basso
    if(map.strutturamappa[pos.posi][pos.posj]->room[pos.posx+1][pos.posy]==' '){
        dist= pow(i-pos.posx,2)+ pow(j-pos.posy,2);
        if(score>dist){
            score=dist;
            poss=3;
        }
        wrefresh(win1);
    }
    
    switch(poss){
        case 0:
            map.strutturamappa[pos.posi][pos.posj]->room[pos.posx][pos.posy-1]=nome;
            map.esistestanza(win1);
            break;
        case 1:
            map.strutturamappa[pos.posi][pos.posj]->room[pos.posx][pos.posy+1]=nome;
             map.esistestanza(win1);
            break;
        case 2:
            map.strutturamappa[pos.posi][pos.posj]->room[pos.posx-1][pos.posy]=nome;
             map.esistestanza(win1);
            break;
        case 3:
            map.strutturamappa[pos.posi][pos.posj]->room[pos.posx+1][pos.posy]=nome;
             map.esistestanza(win1);
            break;
    }
}

void mostro::inseriscimostro(WINDOW *win1, mappa map, position pos){
          map.strutturamappa[pos.posi][pos.posj]->room[4][4]=nome;
    map.esistestanza(win1);
    wrefresh(win1);
    
        
}
