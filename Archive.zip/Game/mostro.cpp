//
//  mostro.cpp
//  Game
//
//  Created by chiara mengoli on 25/10/17.
//  Copyright © 2017 chiara mengoli. All rights reserved.
//

#include "mostro.hpp"
#include <math.h>
#include <iostream>
#include <stdio.h>
#include <time.h>
#include <stdlib.h>
//#include "Position.cpp"

mostro::mostro(){
   nome='M';
    vita=500;
    attacco=900;
    difesa=200;
}


//il mostro attacca il personaggio
void mostro::mostrovscharacter(WINDOW *win1,WINDOW *win2, screen scr,character chr){

//controllo che ci sia vita
    if (chr.vita>0){
        //se l'attacco del personaggi è minore della difesa del mostro tolgo vita al personaggio altrimnti al mostro
        int k=(attacco)-(character::difesa);
        chr.vita=chr.vita-(k*0.1);
        scr.statuspersonaggio(win2, chr.vita,chr.attacco,chr.difesa);
        scr.statusmostro(win2, vita, attacco,difesa);
        if(chr.vivo(win2,scr)==FALSE)
            mvwprintw(win2, 3, 2, "%s", "GAME OVER");
        
        
    }
    
}

//il personaggio attacca il mostro
void mostro::charactervsmostro(WINDOW *win1,WINDOW *win2, screen scr,character chr){
    
    if (vita>0){
        
        int k=(chr.attacco)-(difesa);
        vita=vita-(k*0.1);
        scr.statusmostro(win2, vita, attacco,difesa);
        scr.statuspersonaggio(win2, chr.vita,chr.attacco,chr.difesa);
        if(vivo(win2,scr)==FALSE)
            mvwprintw(win2, 3, 40, "%s", "il mostro è morto");
    }
    

    
    
    
}
void mostro::movimento(WINDOW *win1,WINDOW *win2, mappa mapp, position pos, screen scr,character chr){
    srand((unsigned)time(0));
    int k=(rand()%4+1);

    switch(k)
    {
            //alto
        case 1:{
            
            if(mapp.strutturamappa[mostroi][mostroj]->room[mostrox-1][mostroy] !='-'){
                if(mapp.strutturamappa[mostroi][mostroj]->room[mostrox-1][mostroy]!='/'){

                if(mapp.strutturamappa[mostroi][mostroj]->room[mostrox-1][mostroy] ==chr.nome){
                    mostrovscharacter(win1, win2, scr,chr);
                    mapp.strutturamappa[mostroi][mostroj]->room[mostrox][mostroy]=nome;
                    mapp.esistestanza(win1);
                    
                }
                if(mapp.strutturamappa[mostroi][mostroj]->room[mostrox-1][mostroy] ==' '){
                    mapp.strutturamappa[mostroi][mostroj]->room[mostrox][mostroy]=' ';
                    pos.posx--;
                    mapp.strutturamappa[mostroi][mostroj]->room[mostrox][ mostroy]=nome;
                    mapp.esistestanza(win1);
                }
                }
            }
            else
                mapp.strutturamappa[mostroi][mostroj]->room[mostrox][ mostroy]=nome;
            break;
        }
            
            //basso
        case 2:{
            
            if(mapp.strutturamappa[mostroi][mostroj]->room[mostrox+1][mostroy] !='-'){
               if(mapp.strutturamappa[mostroi][mostroj]->room[mostrox+1][mostroy]!='/'){
                if(mapp.strutturamappa[mostroi][mostroj]->room[mostrox+1][mostroy] ==chr.nome){
                    mostrovscharacter(win1, win2, scr,chr);
                    mapp.strutturamappa[mostroi][mostroj]->room[mostrox][ mostroy]=nome;
                    mapp.esistestanza(win1);
                    
                }
                
                if(mapp.strutturamappa[mostroi][mostroj]->room[mostrox+1][mostroy] ==' '){
                    mapp.strutturamappa[mostroi][mostroj]->room[mostrox][mostroy]=' ';
                    pos.posx++;
                    
                    mapp.strutturamappa[mostroi][mostroj]->room[mostrox][ mostroy]=nome;
                    mapp.esistestanza(win1);
                    
                }
               }
           }
            else
            mapp.strutturamappa[mostroi][mostroj]->room[mostrox][ mostroy]=nome;
            
            break;
        }
            
            
        case 3:{
            //sinistra
            if (mapp.strutturamappa[mostroi][mostroj]->room[mostrox][mostroy+1]!='|' ){
                if(mapp.strutturamappa[mostroi][mostroj]->room[mostrox][mostroy+1]!='/'){
                if(mapp.strutturamappa[mostroi][mostroj]->room[mostrox][mostroy+1] ==chr.nome){
                    mostrovscharacter(win1, win2, scr,chr);
                    
                    mapp.strutturamappa[mostroi][mostroj]->room[mostrox][mostroy]=nome;
                    mapp.esistestanza(win1);
                    
                }
                
                if(mapp.strutturamappa[mostroi][mostroj]->room[mostrox][mostroy+1] ==' '){
                    mapp.strutturamappa[mostroi][mostroj]->room[mostrox][mostroy]=' ';
                    pos.posy++;
                    
                    mapp.strutturamappa[mostroi][mostroj]->room[mostrox][mostroy]=nome;
                    mapp.esistestanza(win1);
                    
                }
            }
            }
            else
                mapp.strutturamappa[mostroi][mostroj]->room[mostrox][ mostroy]=nome;
            break;}
            
            
            
        case 4:{
            //destra
            
            if(mapp.strutturamappa[mostroi][mostroj]->room[mostrox][mostroy-1]!='|'){
                
                if(mapp.strutturamappa[mostroi][mostroj]->room[mostrox][mostroy-1]!='/'){

                if(mapp.strutturamappa[mostroi][mostroj]->room[mostrox][mostroy-1] ==chr.nome){
                    mostrovscharacter(win1, win2, scr,chr);
                    
                    mapp.strutturamappa[mostroi][pos.posj]->room[mostrox][mostroy]=nome;
                    mapp.esistestanza(win1);
                   
                    
                }
                
                if(mapp.strutturamappa[mostroi][mostroj]->room[mostrox][mostroy-1] ==' '){
                    mapp.strutturamappa[mostroi][mostroj]->room[mostrox][ mostroy]=' ';
                    pos.posy--;
                    
                    mapp.strutturamappa[mostroi][mostroj]->room[mostrox][mostroy]=nome;
                    
                    wrefresh(win1);                }
                }
                }
            else
                mapp.strutturamappa[mostroi][mostroj]->room[mostrox][ mostroy]=nome;
            break;}
            
            
            
        default:
            break;
    }
    
    wrefresh(win1);
    
}



void mostro::inseriscimostro(WINDOW *win1, mappa map, position posizione){
          map.strutturamappa[posizione.posi][posizione.posj]->room[4][4]=nome;
    map.esistestanza(win1);
    wrefresh(win1);
    
        
}
