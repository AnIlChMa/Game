#include "stanza.hpp"
#include <iostream>


#include<time.h>
#include<stdio.h>
#include<stdlib.h>
#include<string>
#include <ncurses.h>
#include <curses.h>
using namespace std;
//costruttore -> costruisce una stanza vuota (invisibile)
stanza::stanza()
{
    //ptr=&room[7][7];
    //ctor
    for(int r=0;r<7;r++){
        for(int c=0;c<9;c++){
            room[r][c]=' ';
        }
    }

}

stanza::~stanza()
{
    //dtor

}

//funzione che crea la struttura della stanza nel senso che gli pone i bordi e la rende visibile
   void  stanza::creastanza(){
        for(int r=0;r<7;r++){
            for(int c=0;c<9;c++){
                 room[r][c]=' ';
            }
        }
        for(int r=0;r<7;r++){
                room[r][0]='|';
                room[r][8]='|';
                room[r][9]='\0';
        }
        for(int c=0;c<9;c++){
                room[0][c]='-';
                room[6][c]='-';
        }
       // room[3][4]='v';
       //room[5][5]='a';
    }


//stampa della struttura di una stanza tramite cout (non usata)
   void  stanza::stamparoom(){
         for(int i=1;i<7;i++){
            for(int j=1;j<9;j++){
                cout<<room[i][j];
            }
            cout<<endl;
         }
     }

//funzione che permette di stampare a video, nella finestra di gioco, la stanza; la stanza viene stampata per righe

   void stanza::wprintroom(WINDOW *win1,int x, int y){
//ciclo per stampare la stanza, stampiamo come se fossero "array" di riga
       
                for(int r=0;r<7;r++){
                    
                   mvwprintw(win1,r+x,y,"%s",room[r]);
                }
            wrefresh(win1);
       
    }

  

