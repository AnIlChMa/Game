
//
//  character.cpp
//  Game
//
//  Created by chiara mengoli on 25/10/17.
//  Copyright © 2017 chiara mengoli. All rights reserved.
//

#include "character.hpp"
#include "Position.hpp"
#include "mappa.hpp"
#include "screen.hpp"

character::character()
{
    //ctor
}


bool character::vivo(){
    if(vita<=0)
        return false;
    else
        return true;
}



void character::raccoglioggetti(WINDOW *win1,mappa map,position pos){
    p = new loggetti;
    p->next=NULL;
    int ch=0;
    if((ch=getch())!= 'q')
    {
        switch(ch)
        {
            case KEY_UP:{
                if(map.strutturamappa[pos.posi][pos.posj]->room[pos.posx+1][pos.posy]=='o' ){
                    monete++;
                    if (map.strutturamappa[pos.posi][pos.posj]->room[pos.posx+1][pos.posy]=='X'){
                        p->nomeogg;
                        p->next;
                        if (map.strutturamappa[pos.posi][pos.posj]->room[pos.posx+1][pos.posy]=='j'){
                            p=p->next;
                            p->nomeogg;
                            p->next;}}
                    map.strutturamappa[pos.posi][pos.posj]->room[pos.posx][pos.posy]=' ';
                    pos.posx--;
                    map.strutturamappa[pos.posi][pos.posj]->room[pos.posx][pos.posy]=pos.main_char;
                }
                else
                    map.strutturamappa[pos.posi][pos.posj]->room[pos.posx][pos.posy]=pos.main_char;
                break;
            }
                
            case KEY_DOWN:{
                
                if(map.strutturamappa[pos.posi][pos.posj]->room[pos.posx-1][pos.posy]=='o' ){
                    monete++;
                    if (map.strutturamappa[pos.posi][pos.posj]->room[pos.posx-1][pos.posy]=='X'){
                        p->nomeogg;
                        p->next;
                        if (map.strutturamappa[pos.posi][pos.posj]->room[pos.posx-1][pos.posy]=='j'){
                            p->nomeogg;
                            p->next;}}
                    map.strutturamappa[pos.posi][pos.posj]->room[pos.posx][pos.posy]=' ';
                    pos.posx++;
                    map.strutturamappa[pos.posi][pos.posj]->room[pos.posx][pos.posy]=pos.main_char;}
                else
                    map.strutturamappa[pos.posi][pos.posj]->room[pos.posx][pos.posy]=pos.main_char;
                break;
            }
                
            case KEY_RIGHT:{
                if(map.strutturamappa[pos.posi][pos.posj]->room[pos.posx][pos.posy+1]=='o' ){
                    monete++;
                    if (map.strutturamappa[pos.posi][pos.posj]->room[pos.posx][pos.posy+1]=='X'){
                        p->nomeogg;
                        p->next;
                        if (map.strutturamappa[pos.posi][pos.posj]->room[pos.posx][pos.posy+1]=='j'){
                            p->nomeogg;
                            p->next;}}
                    map.strutturamappa[pos.posi][pos.posj]->room[pos.posx][pos.posy]=' ';
                    pos.posy++;
                    map.strutturamappa[pos.posi][pos.posj]->room[pos.posx][pos.posy]=pos.main_char;}
                else
                    map.strutturamappa[pos.posi][pos.posj]->room[pos.posx][pos.posy]=pos.main_char;
                break;
            }
                
            case KEY_LEFT:{
                if(map.strutturamappa[pos.posi][pos.posj]->room[pos.posx][pos.posy-1]=='o' ){
                    monete++;
                    if (map.strutturamappa[pos.posi][pos.posj]->room[pos.posx][pos.posy-1]=='X'){
                        p->nomeogg;
                        p->next;
                        if (map.strutturamappa[pos.posi][pos.posj]->room[pos.posx][pos.posy-1]=='j'){
                            p->nomeogg;
                            p->next;}}
                    map.strutturamappa[pos.posi][pos.posj]->room[pos.posx][pos.posy]=' ';
                    pos.posy--;
                    map.strutturamappa[pos.posi][pos.posj]->room[pos.posx][pos.posy]=pos.main_char;}
                else
                    map.strutturamappa[pos.posi][pos.posj]->room[pos.posx][pos.posy]=pos.main_char;
                break;
            }
                
            default:
                break;
        }
        wrefresh(win1);
    }
}

void character::usaoggetti(WINDOW *win1,mappa map,position pos){
    if(monete==pos.h){
        for(pos.posx=1;pos.posx<7;pos.posx++){
            for(pos.posy=1;pos.posy<7;pos.posy++){
                
                if(map.strutturamappa[pos.posi][pos.posj]->room[pos.posx][pos.posy]==' ')
                    map.strutturamappa[pos.posi][pos.posj]->room[pos.posx][pos.posy]='j';
            }}
    }
}
