
//
//  character.cpp
//  Game
//
//  Created by chiara mengoli on 25/10/17.
//  Copyright © 2017 chiara mengoli. All rights reserved.
//

#include "character.hpp"
#include "Position.hpp"

character::character()
{
    monete=0;
    nome='$';
    vita=200;
    p= new loggetti;
}


bool character::vivo(WINDOW *win2, screen scr){
    scr.statusvita(win2, vita);
    if(vita<=0)
        return false;
    else
        return true;
}



void character::raccoglioggetti(WINDOW *win1,WINDOW *win2,WINDOW *win3,mappa map,screen scr, position pos, int f){
        switch(f)
        {
                
            case 1:{
                
                if(map.strutturamappa[pos.posi][pos.posj]->room[pos.posx-1][pos.posy]=='o' ){
                    monete++;
                    
                    scr.statusmonete(win2, monete);
                    wrefresh(win2);
                }
                if (map.strutturamappa[pos.posi][pos.posj]->room[pos.posx-1][pos.posy]=='X'){
                        p->next= new loggetti;
                        p=p->next;
                        p->nomeogg='X';
                    scr.listaoggetti(win3, p->nomeogg);
                        p->next=NULL;
                    
                         wrefresh(win3);
                }
                if (map.strutturamappa[pos.posi][pos.posj]->room[pos.posx-1][pos.posy]=='j'){
                    p->next= new loggetti;
                    p=p->next;
                    p->nomeogg='j';
                    
                    scr.listaoggetti(win3, p->nomeogg);
                    p->next=NULL;
                    
                             wrefresh(win3);
                }
                    
                break;
            }
                
            case 3:{
                
                if(map.strutturamappa[pos.posi][pos.posj]->room[pos.posx+1][pos.posy]=='o' ){
                    monete++;
                    
                    scr.statusmonete(win2, monete);
                    wrefresh(win2);
                }
                    if (map.strutturamappa[pos.posi][pos.posj]->room[pos.posx+1][pos.posy]=='X'){
                        p->next= new loggetti;
                        p=p->next;
                        p->nomeogg='X';
                        scr.listaoggetti(win3, p->nomeogg);
                        p->next=NULL;
                       
                         wrefresh(win3);
                    }
                        if (map.strutturamappa[pos.posi][pos.posj]->room[pos.posx+1][pos.posy]=='j'){
                            p->next= new loggetti;
                            p=p->next;
                            p->nomeogg='j';
                            scr.listaoggetti(win3, p->nomeogg);
                            p->next=NULL;
                            
                            wrefresh(win3);
                        }
                    
                
                break;
            }
                
            case 2:{
                if(map.strutturamappa[pos.posi][pos.posj]->room[pos.posx][pos.posy+1]=='o' ){
                    monete++;
                    
                    scr.statusmonete(win2, monete);
                    wrefresh(win2);
                }
                    if (map.strutturamappa[pos.posi][pos.posj]->room[pos.posx][pos.posy+1]=='X'){
                        p->next= new loggetti;
                        p=p->next;
                        p->nomeogg='X';
                        scr.listaoggetti(win3, p->nomeogg);
                        p->next=NULL;
                       
                         wrefresh(win3);
                    }
                        if (map.strutturamappa[pos.posi][pos.posj]->room[pos.posx][pos.posy+1]=='j'){
                            p->next= new loggetti;
                            p=p->next;
                            p->nomeogg='j';
                            scr.listaoggetti(win3, p->nomeogg);
                            p->next=NULL;
                            
                             wrefresh(win3);
                        }
                    
                
                                    break;
            }
                
            case 4:{
                if(map.strutturamappa[pos.posi][pos.posj]->room[pos.posx][pos.posy-1]=='o' ){
                    monete++;
                    scr.statusmonete(win2, monete);
                    wrefresh(win2);
                }
                    if (map.strutturamappa[pos.posi][pos.posj]->room[pos.posx][pos.posy-1]=='X'){
                        p->next= new loggetti;
                        p=p->next;
                        p->nomeogg='X';
                        scr.listaoggetti(win3, p->nomeogg);
                        p->next=NULL;
                        
                         wrefresh(win3);
                    }
                    if (map.strutturamappa[pos.posi][pos.posj]->room[pos.posx][pos.posy-1]=='j'){
                        p->next= new loggetti;
                        p=p->next;
                        p->nomeogg='j';
                        scr.listaoggetti(win3, p->nomeogg);
                        p->next=NULL;
                        
                         wrefresh(win3);
                        }
                    
                
                break;
            }
                
            default:
                break;
            }
        }


 
//questa funzione dovrebbe permettere di usare gli oggeti ->svuotare la lista degli oggetti
//adesso sta generando la chiave, dovrebbe essere integrata alla funzione generahiave
void character::usaoggetti(WINDOW *win1,mappa map, position pos){
    if(monete==pos.h){
        for(pos.posx=1;pos.posx<6;pos.posx++){
            for(pos.posy=1;pos.posy<8;pos.posy++){
                
                if(map.strutturamappa[pos.posi][pos.posj]->room[pos.posx][pos.posy]==' ')
                    map.strutturamappa[pos.posi][pos.posj]->room[pos.posx][pos.posy]='j';
            }
        }
    }
}
