
//
//  character.cpp
//  Game
//
//  Created by chiara mengoli on 25/10/17.
//  Copyright © 2017 chiara mengoli. All rights reserved.
//

#include "character.hpp"
#include "Position.hpp"
#include <ncurses.h>
#include <curses.h>

character::character()
{
    monete=0;
    nome='$';
    vita=200;
    p= new loggetti;
    p->next=NULL;
}


bool character::vivo(WINDOW *win2, screen scr){
    scr.statusvita(win2, vita);
    if(vita<=0)
        return false;
    else
        return true;
}



void character::raccoglioggetti(WINDOW *win1,WINDOW *win2,WINDOW *win3,mappa map,screen scr, position pos, int f){
    
    
       p1=p;
        while (p1->next != NULL){
            p1 = p1->next;
        }
        p1->next = new loggetti;
        p1= p1->next;
    
        switch(f)
        {
                
            case 1:{
                
                if(map.strutturamappa[pos.posi][pos.posj]->room[pos.posx-1][pos.posy]=='o' ){
                    monete++;
                    
                    scr.statusmonete(win2, monete);
                    wrefresh(win2);
                }
                if (map.strutturamappa[pos.posi][pos.posj]->room[pos.posx-1][pos.posy]=='X'){
                        p1->nomeogg='X';
                   listaoggetti(win3);
                        p1->next=NULL;
                    
                         wrefresh(win3);
                }
                if (map.strutturamappa[pos.posi][pos.posj]->room[pos.posx-1][pos.posy]=='j'){
                    
                    p1->nomeogg='j';
                    
                    listaoggetti(win3);
                    p1->next=NULL;
                    
                             wrefresh(win3);
                }
                    
                break;
            }
                
            case 3:{
                
                if(map.strutturamappa[pos.posi][pos.posj]->room[pos.posx+1][pos.posy]=='o' ){
                    monete++;
                    
                    scr.statusmonete(win2, monete);
                    wrefresh(win2);
                }
                    if (map.strutturamappa[pos.posi][pos.posj]->room[pos.posx+1][pos.posy]=='X'){
                        
                        p1->nomeogg='X';
                        listaoggetti(win3);
                        p1->next=NULL;
                       
                         wrefresh(win3);
                    }
                        if (map.strutturamappa[pos.posi][pos.posj]->room[pos.posx+1][pos.posy]=='j'){
                            
                            p1->nomeogg='j';
                            listaoggetti(win3);
                            p1->next=NULL;
                            
                            wrefresh(win3);
                        }
                    
                
                break;
            }
                
            case 2:{
                if(map.strutturamappa[pos.posi][pos.posj]->room[pos.posx][pos.posy+1]=='o' ){
                    monete++;
                    
                    scr.statusmonete(win2, monete);
                    wrefresh(win2);
                }
                    if (map.strutturamappa[pos.posi][pos.posj]->room[pos.posx][pos.posy+1]=='X'){
                        
                        p1->nomeogg='X';
                        listaoggetti(win3);
                        p1->next=NULL;
                       
                         wrefresh(win3);
                    }
                        if (map.strutturamappa[pos.posi][pos.posj]->room[pos.posx][pos.posy+1]=='j'){
                            
                            p1->nomeogg='j';
                            listaoggetti(win3);
                            p1->next=NULL;
                            
                             wrefresh(win3);
                        }
                    
                
                                    break;
            }
                
            case 4:{
                if(map.strutturamappa[pos.posi][pos.posj]->room[pos.posx][pos.posy-1]=='o' ){
                    monete++;
                    scr.statusmonete(win2, monete);
                    wrefresh(win2);
                }
                    if (map.strutturamappa[pos.posi][pos.posj]->room[pos.posx][pos.posy-1]=='X'){
                       
                        p1->nomeogg='X';
                        listaoggetti(win3);
                        p1->next=NULL;
                        
                         wrefresh(win3);
                    }
                    if (map.strutturamappa[pos.posi][pos.posj]->room[pos.posx][pos.posy-1]=='j'){
                        
                        p1->nomeogg='j';
                        listaoggetti(win3);
                        p1->next=NULL;
                        
                         wrefresh(win3);
                        }
                    
                
                break;
            }
                
            default:
                break;
            }
    
        }


 
//questa funzione dovrebbe permettere di usare gli oggeti ->svuotare la lista degli oggetti
//adesso sta generando la chiave, dovrebbe essere integrata alla funzione generahiave
void character::usaoggetti(WINDOW *win1,WINDOW *win3,mappa map, position pos ,screen scr){
    int ch=0;
    if((ch=getch())!='q'){
        switch (ch) {
            case 'j':
            {
                while (p->next != NULL){
                    if(p->nomeogg=='j'){
                        p->next=p->next->next;
                        listaoggetti(win3);
                    }
                    
                    
                    p=p->next;
                }
            
            }
                break;
            case 'x':
            {
            
                while (p->next != NULL){
                    if(p->nomeogg=='X'){
                        p->next=p->next->next;
                        listaoggetti(win3);
                    }
                    p=p->next;
                }
            }
                break;
            default:
                break;
        }
        
        
    }
    
    
    /*if(monete==pos.h){
        for(pos.posx=1;pos.posx<6;pos.posx++){
            for(pos.posy=1;pos.posy<8;pos.posy++){
                
                if(map.strutturamappa[pos.posi][pos.posj]->room[pos.posx][pos.posy]==' ')
                    map.strutturamappa[pos.posi][pos.posj]->room[pos.posx][pos.posy]='j';
            }
        }
    }*/
}
void character::listaoggetti(WINDOW *win3){
    int r;
     while (p1->next != NULL) {
         mvwprintw(win3,r,3,"%c",nome);
         wrefresh(win3);
         p1= p1->next;
         r++;
     }
    
    
    
    
}
