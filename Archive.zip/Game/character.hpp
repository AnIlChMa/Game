//
//  character.hpp
//  Game
//
//  Created by chiara mengoli on 25/10/17.
//  Copyright © 2017 chiara mengoli. All rights reserved.
//

#ifndef character_hpp
#define character_hpp

#include <stdio.h>

#include "mappa.hpp"
#include "screen.hpp"




class position;
class character {
public:
    character();
    
    //battaglia(WINDOW *win1);
    bool vivo(WINDOW *win2, screen scr);
   void raccoglioggetti(WINDOW *win1, WINDOW *win2,WINDOW *win3,mappa map, screen scr,position pos, int f);
   void usaoggetti(WINDOW *win1,WINDOW *win3, mappa map,position pos,screen scr);
    void listaoggetti(WINDOW *win3);
    int monete;
     char nome;
    char descr;
    int vita;
    int difesa;
    int attacco;
    struct loggetti{
        char nomeogg;
        loggetti *next;
    };
    typedef loggetti *ptr_oggetti;
    ptr_oggetti p;
    ptr_oggetti p1;
    
private:

};



#endif /* character_hpp */
