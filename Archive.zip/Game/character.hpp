//
//  character.hpp
//  Game
//
//  Created by chiara mengoli on 25/10/17.
//  Copyright © 2017 chiara mengoli. All rights reserved.
//

#ifndef character_hpp
#define character_hpp

#include <stdio.h>

#include "mappa.hpp"
#include "screen.hpp"
//#include "Position.hpp"



class position;
class character {
public:
    character();
    
    //battaglia(WINDOW *win1);
    bool vivo(WINDOW *win2, screen scr);
   void raccoglioggetti(WINDOW *win1, WINDOW *win2,mappa map, screen scr,position pos);
   void usaoggetti(WINDOW *win1, mappa map,position pos);
    int monete;
     char nome;
    char descr;
    int vita;
    int difesa;
    int attacco;
    struct loggetti{
        char nomeogg;
        loggetti *next;
    };
    typedef loggetti *ptr_oggetti;
    ptr_oggetti p;
    
    
private:

};



#endif /* character_hpp */
