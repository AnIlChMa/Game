//
//  character.hpp
//  Game
//
//  Created by chiara mengoli on 25/10/17.
//  Copyright © 2017 chiara mengoli. All rights reserved.
//

#ifndef character_hpp
#define character_hpp

#include <stdio.h>
#include "screen.hpp"
class character {
public:
    character();
    //funzione che gestisce l'attacco con i mostri
    void battaglia(WINDOW *win1);
    //funzione che restituisce true se il personaggio è ancora vivo, false altrimenti
    bool vivo();
    
    struct loggetti{
        char nomeogg;
        loggetti *next;
    };
    
    //funzione che permette al personaggio di raccogliere gli oggetti e li inserisce in una lista
    void raccoglioggetti();
    //l'utente deve inserire il carattere dell'oggetto che vuole usare e premere un tasto per dare l'ok
    void usaoggetti();
    
protected:
    
    char descr;
    int alive;
    char nome;
    int difesa;
    int attacco;
    
};



#endif /* character_hpp */
