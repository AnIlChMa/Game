#ifndef STANZA_H
#define STANZA_H
#include<vector>
#include<iostream>
#include "screen.hpp"



using namespace std;

class stanza
{
    public:
        stanza();
        

        virtual ~stanza();
        void creastanza();
        void stamparoom();
        void creaporta();
        void wprintroom(WINDOW *win1, int x, int y);
        char room[7][10];
};

#endif // STANZA_H
